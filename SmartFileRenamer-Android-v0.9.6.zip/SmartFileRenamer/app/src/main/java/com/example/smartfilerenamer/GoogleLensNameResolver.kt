package com.example.smartfilerenamer

import android.content.Context
import android.net.Uri
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.jsoup.Jsoup
import java.io.IOException
import java.util.Locale
import java.util.concurrent.TimeUnit

/** Experimental Google Lens web upload. This uses an undocumented endpoint and may stop working. */
object GoogleLensNameResolver {
    private val client = OkHttpClient.Builder()
        .connectTimeout(25, TimeUnit.SECONDS)
        .readTimeout(45, TimeUnit.SECONDS)
        .writeTimeout(45, TimeUnit.SECONDS)
        .callTimeout(60, TimeUnit.SECONDS)
        .followRedirects(true)
        .build()
    @Volatile private var activeCall: okhttp3.Call? = null

    fun cancelActiveRequest() { activeCall?.cancel(); activeCall = null }

    private val generic = setOf("google lens", "google", "search", "images", "image search", "visual matches", "results", "lens")
    private val badChars = Regex("""[\\/:*?\"<>|\p{Cntrl}]""")
    private val spaces = Regex("\\s+")

    fun suggestBaseName(context: Context, uri: Uri): String? {
        val bytes = context.contentResolver.openInputStream(uri)?.use { input ->
            val out = java.io.ByteArrayOutputStream()
            val buffer = ByteArray(16 * 1024)
            var total = 0
            while (true) {
                val n = input.read(buffer)
                if (n < 0) break
                total += n
                if (total > 12 * 1024 * 1024) throw IOException("Image is larger than 12 MB; Google Lens lookup skipped.")
                out.write(buffer, 0, n)
            }
            out.toByteArray()
        } ?: throw IOException("Android could not read this image.")
        if (bytes.isEmpty()) throw IOException("Image file is empty.")
        val mime = context.contentResolver.getType(uri)?.takeIf { it.startsWith("image/") } ?: "image/jpeg"
        val body = MultipartBody.Builder().setType(MultipartBody.FORM)
            .addFormDataPart("encoded_image", "image", bytes.toRequestBody(mime.toMediaType()))
            .build()
        val request = Request.Builder()
            .url("https://lens.google.com/v3/upload")
            .header("User-Agent", "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/126.0.0.0 Mobile Safari/537.36")
            .header("Origin", "https://lens.google.com")
            .header("Referer", "https://lens.google.com/")
            .post(body)
            .build()
        val call = client.newCall(request)
        activeCall = call
        val html = call.execute().use { response ->
            val text = response.body?.string().orEmpty()
            if (!response.isSuccessful) throw IOException("Google Lens upload failed (${response.code}); leaving the original name unchanged.")
            if (text.isBlank()) throw IOException("Google Lens returned an empty page.")
            text
        }.also { activeCall = null }
        val doc = Jsoup.parse(html)
        val catalog = YgoProDeckResolver.prepare(context)
        val candidates = linkedSetOf<String>()
        // Lens result pages vary by device/session. Collect visible result text as well as
        // structured title fields; the older parser only read headings and often saw no card.
        doc.select("meta[property=og:title], meta[name=title], meta[property=og:description], meta[name=description]").forEach {
            it.attr("content").takeIf(String::isNotBlank)?.let(candidates::add)
        }
        doc.select("h1, h2, h3, a[href], [role=heading], [data-attrid]").take(500).forEach { el ->
            el.text().trim().takeIf { it.length in 3..300 }?.let(candidates::add)
            el.attr("aria-label").takeIf { it.length in 3..300 }?.let(candidates::add)
        }
        doc.select("script").forEach { script ->
            val t = script.data()
            Regex("""\"(?:title|text|query|snippet|description)\"\s*:\s*\"([^\"]{3,300})\""", RegexOption.IGNORE_CASE)
                .findAll(t).take(300).forEach { candidates.add(it.groupValues[1]) }
        }
        // Match a complete official card name occurring inside a Lens result snippet.
        // Reject commercial poster/print listings so a product title cannot become a card name.
        val productContext = Regex("\\b(poster|wall\\s*art|canvas|print|merchandise|decoration|framed\\s*art)\\b", RegexOption.IGNORE_CASE)
        val officialNames = catalog.normalizedNameToOfficialName.entries
            .sortedByDescending { it.value.length }
        for (raw in candidates) {
            val cleaned = clean(raw) ?: continue
            if (productContext.containsMatchIn(cleaned)) continue
            val normalized = cleaned.lowercase(Locale.ROOT).replace("&", " and ")
            val matches = officialNames.filter { (_, official) ->
                Regex("(?<![\\p{L}\\p{N}])" + Regex.escape(official) + "(?![\\p{L}\\p{N}])", RegexOption.IGNORE_CASE)
                    .containsMatchIn(normalized)
            }
            if (matches.isNotEmpty()) {
                // Prefer the longest specific card name; names like "Dark Magician" should
                // not beat "Dark Magician Girl" when both occur in the same result text.
                return matches.first().value
            }
        }

        return null
    }

    private fun clean(raw: String): String? {
        val value = spaces.replace(raw.replace(badChars, " ").replace('_', ' '), " ").trim(' ', '.', '-', '_')
            .take(140).trim()
        if (value.length < 3 || value.lowercase(Locale.ROOT) in generic) return null
        if (value.contains("Google Lens", ignoreCase = true)) return null
        return value
    }

    private fun matchOfficialCardName(candidate: String, officialNames: Map<String, String>): String? {
        val normalizedCandidate = candidate.lowercase(Locale.ROOT)
            .replace("&", " and ")
            .replace(Regex("[^\\p{L}\\p{N}]+"), "")
        if (normalizedCandidate.isBlank()) return null
        // Exact normalized match only. Substring/fuzzy matching can mistake a poster title,
        // product listing or unrelated page heading that merely mentions a card.
        return officialNames[normalizedCandidate]
    }

}
