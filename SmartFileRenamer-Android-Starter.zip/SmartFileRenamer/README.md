# Smart File Renamer Android

Version 0.7.0 experimental. Android app using the Storage Access Framework to rename accessible files and export selected files/folders to a ZIP.

## Current behavior
- Folder scans recurse into accessible subfolders. There is no hard-coded nine-file or other fixed file-count limit.
- The background worker attempts every discovered file, continues after individual failures, and reports processed / renamed / unchanged / failed counts.
- A rename is counted as successful only when the resulting display name can be verified.
- Progress is written to WorkManager and shown in the ongoing notification where Android allows it.
- `Save / Export selected files as ZIP` lets the user choose a destination on the device. It includes accessible files from selected folders.
- `Share renamed files / Email` creates a temporary ZIP and opens Android’s share chooser, allowing the user to pick Gmail, another email app, or another compatible sharing app without first saving a copy manually.
- Sharing uses Android FileProvider to grant temporary read access to the ZIP; the share flow still requires testing on a real device and with the target email app.

## Build
The repository's current GitHub Actions workflow expects the project nested under `SmartFileRenamer/`. It may insert an unused `workDataOf` import during the build; that is harmless.

## Important
A successful APK compilation is not proof that every Android document provider permits renaming. The app verifies results and reports failures rather than claiming unverified success. Actual device testing is still required.


Version 0.4.1 test fix: folder scanning no longer relies on `DocumentFile.isFile`, because some Android document providers report null/unknown MIME types for real files. Non-directory document entries are treated as file candidates and then validated during access/rename. This is a diagnostic fix and still needs a device test against the affected folder provider.


## Version 0.4.2 test notes
- Hardened the Android file-picker result callback so unexpected provider results are handled as an on-screen error instead of escaping the callback.
- Made selected-file labels defensive against document-provider errors.
- This is a diagnostic hardening pass; it has not been compiled or tested on a physical device in this environment. If the crash persists, capture the Android crash/Logcat stack trace to identify the exact failing line.


## Diagnostic build 0.4.3
This build records uncaught runtime exceptions locally. If the app crashes, reopen it and tap **Copy last crash report for diagnosis**, then share the copied text with the developer. This is a diagnostic aid, not a confirmed fix for the current crash.


## Version 0.5.0 — Google image matching (needs API setup and device testing)
- Image files are sent to Google Cloud Vision Web Detection. The app uses useful web entities or best-guess labels to propose a meaningful filename, preserving the original extension.
- The old behavior that blindly added `Image`, `Document`, `Video`, or similar prefixes has been removed. Non-image files receive conservative separator cleanup only.
- The Google Cloud Vision API key is entered and saved on the device; no API key is bundled into the app source. Image identification requires a Google Cloud project with the Vision API enabled, billing configured, and a valid API key.
- Image contents are uploaded to Google for matching. Web Detection pricing is listed by Google as $3.50 per 1,000 units after the first 1,000 monthly free units; a 20,000-image batch may cost about $66.50 if those free units are available and no other charges apply. Check current Google Cloud pricing before processing large folders.
- This is an initial implementation and has not yet been verified by an Android build or physical-device test. Test with a few non-sensitive images first, then check the rename and export flows before processing a large folder.


## Version 0.6.0 — free-first image recognition (not yet build/device tested)
- Added bundled Google ML Kit on-device image labeling as the default for image files. The model labels common objects and scenes without uploading the image or charging per image. It is not reverse-image search and may produce broad labels.
- Google Cloud Vision Web Detection is now explicitly opt-in through the “Allow paid Google web matching” switch, which is OFF by default. If enabled and a key is saved, the worker tries web matching first and falls back to local labels if web matching fails.
- If neither service provides a useful label, the image is counted as failed rather than renamed with a generic prefix.
- This build still needs GitHub Actions compilation and physical-device tests.


## Version 0.7.0 — experimental automatic Google Lens-style lookup
- The background worker now attempts an image upload to Google's Lens web endpoint first, then falls back to on-device ML Kit if the online lookup fails or gives no usable label.
- Removed the Cloud Vision API key and paid-service switch from the UI; this build does not call Cloud Vision.
- **Important limitation:** Google Lens does not provide a supported public API for this workflow. This build uses an undocumented web endpoint and parses returned HTML, so Google may block it or change the page at any time. It has not been compiled or device-tested here.
- Images are uploaded to Google for online matching. Use only with images you are comfortable sending to Google. This is an experimental personal-use prototype, not a dependable or publication-ready implementation.
- Unmatched files should remain unchanged if neither online matching nor local recognition returns a useful label. Back up files before trying it on a large collection.
