# Smart File Renamer Android

Version 0.3.0. Android app using the Storage Access Framework to rename accessible files and export selected files/folders to a ZIP.

## Current behavior
- Folder scans recurse into accessible subfolders. There is no hard-coded nine-file or other fixed file-count limit.
- The background worker attempts every discovered file, continues after individual failures, and reports processed / renamed / unchanged / failed counts.
- A rename is counted as successful only when the resulting display name can be verified.
- Progress is written to WorkManager and shown in the ongoing notification where Android allows it.
- `Save / Export selected files as ZIP` lets the user choose a destination on the device. It includes accessible files from selected folders.
- `Share renamed files / Email` creates a temporary ZIP and opens Android’s share chooser, allowing the user to pick Gmail, another email app, or another compatible sharing app without first saving a copy manually.
- Sharing uses Android FileProvider to grant temporary read access to the ZIP; the share flow still requires testing on a real device and with the target email app.

## Build
The repository's current GitHub Actions workflow expects the project nested under `SmartFileRenamer/`. It may insert an unused `workDataOf` import during the build; that is harmless.

## Important
A successful APK compilation is not proof that every Android document provider permits renaming. The app verifies results and reports failures rather than claiming unverified success. Actual device testing is still required.


Version 0.4.1 test fix: folder scanning no longer relies on `DocumentFile.isFile`, because some Android document providers report null/unknown MIME types for real files. Non-directory document entries are treated as file candidates and then validated during access/rename. This is a diagnostic fix and still needs a device test against the affected folder provider.


## Version 0.4.2 test notes
- Hardened the Android file-picker result callback so unexpected provider results are handled as an on-screen error instead of escaping the callback.
- Made selected-file labels defensive against document-provider errors.
- This is a diagnostic hardening pass; it has not been compiled or tested on a physical device in this environment. If the crash persists, capture the Android crash/Logcat stack trace to identify the exact failing line.
