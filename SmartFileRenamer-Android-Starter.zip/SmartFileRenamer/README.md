# Smart File Renamer Android — v0.10.0 visual Yu-Gi-Oh! card matching

This build is designed for existing Yu-Gi-Oh! card-image files. It does not use the camera.
Choose individual images or a folder; the app compares the image pixels against reference card images in the free YGOPRODeck database and uses the official database card name for a confident match.

## Recognition design

- Downloads the YGOPRODeck v7 card catalog and reads every `card_images` reference, including alternate artwork image IDs and each small reference-image URL.
- Builds a local perceptual-image fingerprint index from those reference images. The first scan must download the reference images and can take a while and use substantial network data and phone storage. The index is cached on the device and reused on later scans.
- Compares the uploaded image's full-card and illustration-region visual fingerprints against the catalog fingerprints. It does not use Google Lens, OCR/title-area text, generic image labels, or a paid image-recognition API.
- Uses a conservative distance and runner-up margin. If the visual match is weak or ambiguous, the image is left unchanged.
- The visual index is only considered ready when all catalog image references have been indexed. If downloads fail, the run stops before renaming anything; rerunning resumes by fetching missing references.
- The app defaults to **Preview only**. Review a small batch before disabling preview and renaming real files.

## Other behavior

- Supports Android document-picker selection of individual images and folders, including nested files.
- Background WorkManager operation with foreground progress notification.
- Keeps the original extension and adds numbered suffixes when multiple images resolve to the same card name.
- Unmatched and ambiguous images remain unchanged.

## Important testing note

This is a first implementation of visual matching, not a measured accuracy claim. Perceptual hashes are a lightweight free on-device method; photographs with glare, perspective distortion, heavy crops, sleeves, low resolution, or visually similar alternate artworks may remain unmatched or require threshold tuning. Test Preview mode against a representative set of your actual images before enabling file changes. No 90% accuracy claim is made until that test is completed.

## Reference

YGOPRODeck API: https://db.ygoprodeck.com/api/v7/cardinfo.php
