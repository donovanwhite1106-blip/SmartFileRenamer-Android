# Smart File Renamer Android — v0.9.0 visual card matching

This version is designed for Yu-Gi-Oh! card-image folders such as `Folder 1.zip` (4,468 JPG files, most named with numeric image IDs).

## What changed in v0.9.0

- Adds ONNX Runtime for Android and the YugiScan ViT card-image classifier.
- On the first image batch, downloads `vit_classifier_int8.onnx` and `card_labels.json` from the publisher's V3.0 release. Both downloads are checked against the exact SHA-256 checksums published in `models.json`, written atomically, and cached in app-private storage.
- Runs image inference locally on the phone. It uses a balanced 55% top-score threshold; lower-confidence images are not visually renamed.
- Keeps the existing free YGOPRODeck numeric-ID and exact-name resolver as a fallback when the visual model is unavailable or does not return a high-confidence match.
- Preserves preview-only mode by default, background WorkManager processing, duplicate-name suffixes, and verified rename operations.
- Model attribution and licensing information are in `MODEL-NOTICE.txt`.

The first visual-model setup needs internet and enough free storage for the classifier and labels. After both files are cached, image inference itself is offline. This package downloads the model at runtime rather than embedding a large binary in the source ZIP.

## First test on a phone

1. Install the APK produced by the repository's GitHub Actions build.
2. Open Smart File Renamer and keep **Preview only — do not change files** checked.
3. Choose **Pick files** and select only 5 JPG images from the extracted card folder (including images with non-numeric filenames). You can also pick a folder, but a five-file test is recommended first.
4. Start the run and wait for the completion notification. The first run needs internet access to download the catalog; later runs use the cached catalog.
5. Review the preview's proposed names. If the catalog cannot be downloaded, the app should leave images unchanged and report that reason.
6. Only after the preview names are correct, select a small backed-up test batch and turn preview off. Do not start with all 4,468 files until the small test is satisfactory.

## Build

The project is nested under `SmartFileRenamer/` for the repository's existing workflow, which unpacks `SmartFileRenamer-Android-Starter.zip`, then runs `gradle assembleDebug` on Java 17. The debug APK is uploaded as the `SmartFileRenamer-APK` workflow artifact.

## Important limitations

- Visual matching depends on the upstream model and label release being reachable on first setup. This source package has not been compiled or run on a physical Android device in this environment. The model preprocessing and label-index assumptions therefore still require a first GitHub Actions build and on-device preview check before turning preview off.
- The supplied archive has 4,468 JPG files, 4,429 with numeric basenames and 39 with non-numeric names. The catalog mapping should cover the numeric ones only when their basename matches a YGOPRODeck `card_images[].id` value. Non-matches are deliberately not guessed.
- This source package has been statically inspected and ZIP integrity can be checked locally, but it has **not** been compiled with Gradle or tested on a physical Android device in this environment. The GitHub Actions build and the first on-device preview are still required before a real rename run.

## Reference

YGOPRODeck API Guide: https://ygoprodeck.com/api-guide/
The API guide recommends caching the catalog and image data locally, and warns against repeatedly hotlinking image files. This implementation requests the catalog only and caches its response; it does not download every card image.
