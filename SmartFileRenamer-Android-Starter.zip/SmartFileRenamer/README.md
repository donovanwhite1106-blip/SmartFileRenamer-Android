# Smart File Renamer — progress/rename fix

This build adds real Android document-provider rename calls for selected files, recursive traversal for selected folders, foreground WorkManager progress notifications, and a completion summary notification. Names are cleaned and categorized with simple local filename heuristics.

## Limitations
- Renaming works only when the chosen Android document provider permits rename/write access. If it refuses, the completion notification reports failed items.
- Folder contents are processed recursively, but folder names themselves are not changed.
- ZIP files are renamed as files; extraction and ZIP export are not implemented.
- Online identification is not implemented.
- Please verify on a device; no physical Samsung device is available here for crash testing.

## Build
JDK 17 and Gradle 8.9; the GitHub Actions workflow can build the debug APK.
