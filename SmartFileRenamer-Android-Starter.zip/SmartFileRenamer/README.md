# Smart File Renamer Android

Version 0.2.0. Android app using the Storage Access Framework to rename accessible files and export selected files/folders to a ZIP.

## Current behavior
- Folder scans recurse into accessible subfolders. There is no hard-coded nine-file or other fixed file-count limit.
- The background worker attempts every discovered file, continues after individual failures, and reports processed / renamed / unchanged / failed counts.
- A rename is counted as successful only when the resulting display name can be verified.
- Progress is written to WorkManager and shown in the ongoing notification where Android allows it.
- The `Download / Export selected files as ZIP` action lets the user choose a destination. It includes accessible files from selected folders and reports skipped items.

## Build
The repository's current GitHub Actions workflow expects the project nested under `SmartFileRenamer/`. It may insert an unused `workDataOf` import during the build; that is harmless.

## Important
A successful APK compilation is not proof that every Android document provider permits renaming. The app verifies results and reports failures rather than claiming unverified success. Actual device testing is still required.
