package com.example.smartfilerenamer

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.util.concurrent.Callable
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.min

/**
 * Offline-capable visual card matcher backed by YGOPRODeck's public card-image catalog.
 * It compares the uploaded image pixels to reference card artwork (perceptual hashes); it
 * never asks a search engine to label the image and never uses title-area OCR.
 *
 * First use builds a local fingerprint index from YGOPRODeck's small reference images. This
 * is a one-time, data-heavy download; fingerprints are cached and reused on later scans.
 */
object CardVisualMatcher {
    private const val INDEX_FILE = "ygoprodeck-visual-index-v1.json"
    private const val MATCH_MAX_DISTANCE = 13
    private const val MIN_MARGIN = 2
    private const val SAVE_EVERY = 200
    @Volatile private var cachedFingerprints: Map<String, Fingerprint>? = null
    @Volatile private var cachedReferences: Map<String, YgoProDeckResolver.CardImageReference>? = null
    private val imageClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(25, TimeUnit.SECONDS)
        .callTimeout(35, TimeUnit.SECONDS)
        .build()

    data class Fingerprint(val full: Long, val artwork: Long)
    data class Match(val officialName: String, val imageId: String, val distance: Int)

    /** Builds/extends the local visual index. Returns count of usable reference images. */
    suspend fun prepareIndex(context: Context, onProgress: suspend (Int, Int) -> Unit = { _, _ -> }): Int = withContext(Dispatchers.IO) {
        val catalog = YgoProDeckResolver.prepare(context)
        val indexFile = File(context.filesDir, INDEX_FILE)
        val hashes = readIndex(indexFile)
        val missing = catalog.cardImages.filterNot { hashes.containsKey(it.imageId) }
        if (missing.isNotEmpty()) {
            // A small worker pool avoids serial downloads while keeping load on the public image CDN modest.
            val executor = Executors.newFixedThreadPool(5)
            try {
                var completed = 0
                val futures = missing.map { reference ->
                    executor.submit(Callable {
                        val bitmap = downloadReference(reference.smallImageUrl)
                        val fingerprint = bitmap?.let { try { fingerprint(it) } finally { it.recycle() } }
                        reference.imageId to fingerprint
                    })
                }
                futures.forEachIndexed { index, future ->
                    val result = runCatching { future.get() }.getOrNull()
                    if (result != null && result.second != null) hashes[result.first] = result.second!!
                    completed++
                    if (completed % SAVE_EVERY == 0 || completed == missing.size) writeIndex(indexFile, hashes)
                    if (completed % 10 == 0 || completed == missing.size) onProgress(completed, missing.size)
                }
            } finally {
                executor.shutdownNow()
            }
            writeIndex(indexFile, hashes)
        }
        if (hashes.size < catalog.cardImages.size) {
            writeIndex(indexFile, hashes)
            throw IOException("The visual database is incomplete: indexed ${hashes.size} of ${catalog.cardImages.size} card images. No files were renamed. Check your connection and run the scan again to finish downloading missing references.")
        }
        cachedFingerprints = hashes.toMap()
        cachedReferences = catalog.cardImages.associateBy { it.imageId }
        hashes.size
    }

    /** Compare a selected image against the cached YGOPRODeck visual index. */
    fun identify(context: Context, uri: Uri): Match? {
        val catalog = YgoProDeckResolver.prepare(context)
        val hashes = cachedFingerprints ?: readIndex(File(context.filesDir, INDEX_FILE)).also { cachedFingerprints = it }
        if (hashes.isEmpty()) throw IOException("The card-image reference index has not been built yet.")
        val input = context.contentResolver.openInputStream(uri)?.use { stream ->
            val output = java.io.ByteArrayOutputStream()
            val buffer = ByteArray(16 * 1024)
            var count = 0
            while (true) {
                val read = stream.read(buffer)
                if (read < 0) break
                count += read
                if (count > 20 * 1024 * 1024) throw IOException("Image is larger than 20 MB; skipped to protect phone memory.")
                output.write(buffer, 0, read)
            }
            val bytes = output.toByteArray()
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
            var sample = 1
            while (bounds.outWidth / sample > 1600 || bounds.outHeight / sample > 1600) sample *= 2
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = sample })
        } ?: throw IOException("Android could not decode this image.")
        val query = try { fingerprint(input) } finally { input.recycle() }
        val byId = cachedReferences ?: catalog.cardImages.associateBy { it.imageId }.also { cachedReferences = it }
        var bestId: String? = null
        var bestDistance = Int.MAX_VALUE
        var secondDistance = Int.MAX_VALUE
        for ((id, reference) in hashes) {
            val distance = min(hamming(query.artwork, reference.artwork), hamming(query.full, reference.full))
            if (distance < bestDistance) {
                secondDistance = bestDistance
                bestDistance = distance
                bestId = id
            } else if (distance < secondDistance) {
                secondDistance = distance
            }
        }
        // Require both a close visual match and a separation from the runner-up. Ambiguous
        // results are intentionally not renamed; a wrong filename is worse than no rename.
        if (bestId == null || bestDistance > MATCH_MAX_DISTANCE || secondDistance - bestDistance < MIN_MARGIN) return null
        val officialName = byId[bestId]?.officialName ?: catalog.imageIdToName[bestId] ?: return null
        return Match(officialName, bestId, bestDistance)
    }

    private fun downloadReference(url: String): Bitmap? {
        val request = Request.Builder().url(url).header("User-Agent", "SmartFileRenamer-Android/1.0").build()
        return runCatching {
            imageClient.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return@use null
                val body = response.body ?: return@use null
                body.byteStream().use { BitmapFactory.decodeStream(it) }
            }
        }.getOrNull()
    }

    private fun readIndex(file: File): MutableMap<String, Fingerprint> {
        if (!file.exists()) return HashMap()
        return runCatching {
            val array = JSONArray(file.readText(Charsets.UTF_8))
            HashMap<String, Fingerprint>(array.length()).apply {
                for (i in 0 until array.length()) {
                    val item = array.optJSONObject(i) ?: continue
                    val id = item.optString("id")
                    if (id.isNotBlank()) put(id, Fingerprint(item.optString("full").toULong(16).toLong(), item.optString("art").toULong(16).toLong()))
                }
            }
        }.getOrDefault(HashMap())
    }

    private fun writeIndex(file: File, hashes: Map<String, Fingerprint>) {
        val array = JSONArray()
        hashes.forEach { (id, hash) ->
            array.put(JSONObject().put("id", id).put("full", java.lang.Long.toUnsignedString(hash.full, 16)).put("art", java.lang.Long.toUnsignedString(hash.artwork, 16)))
        }
        val temp = File(file.parentFile, "$INDEX_FILE.tmp")
        temp.writeText(array.toString(), Charsets.UTF_8)
        if (!temp.renameTo(file)) {
            file.writeText(array.toString(), Charsets.UTF_8)
            temp.delete()
        }
    }

    /** 64-bit DCT perceptual hash for the full card and the illustration window. */
    private fun fingerprint(source: Bitmap): Fingerprint {
        val full = perceptualHash(source, 0f, 0f, 1f, 1f)
        // Standard Yu-Gi-Oh! card images place their illustration in the upper-middle frame.
        // This crop reduces sensitivity to text, borders, and card-frame differences.
        val art = perceptualHash(source, 0.08f, 0.17f, 0.92f, 0.62f)
        return Fingerprint(full, art)
    }

    private fun perceptualHash(source: Bitmap, left: Float, top: Float, right: Float, bottom: Float): Long {
        val l = (source.width * left).toInt().coerceIn(0, source.width - 1)
        val t = (source.height * top).toInt().coerceIn(0, source.height - 1)
        val r = (source.width * right).toInt().coerceIn(l + 1, source.width)
        val b = (source.height * bottom).toInt().coerceIn(t + 1, source.height)
        val crop = Bitmap.createBitmap(source, l, t, r - l, b - t)
        val scaled = Bitmap.createScaledBitmap(crop, 32, 32, true)
        val pixels = IntArray(32 * 32)
        scaled.getPixels(pixels, 0, 32, 0, 0, 32, 32)
        if (scaled !== source) scaled.recycle()
        if (crop !== source && crop !== scaled) crop.recycle()
        val gray = Array(32) { y -> DoubleArray(32) { x ->
            val color = pixels[y * 32 + x]
            val red = (color shr 16) and 255
            val green = (color shr 8) and 255
            val blue = color and 255
            0.299 * red + 0.587 * green + 0.114 * blue
        } }
        val coefficients = DoubleArray(64)
        val cosX = Array(8) { u -> DoubleArray(32) { x -> kotlin.math.cos((2 * x + 1) * u * Math.PI / 64.0) } }
        val cosY = Array(8) { v -> DoubleArray(32) { y -> kotlin.math.cos((2 * y + 1) * v * Math.PI / 64.0) } }
        // Separable DCT: same low-frequency fingerprint as the direct 2-D transform,
        // but far fewer operations on the phone during the first catalog build.
        val horizontal = Array(32) { DoubleArray(8) }
        for (y in 0 until 32) for (u in 0 until 8) {
            var sum = 0.0
            for (x in 0 until 32) sum += gray[y][x] * cosX[u][x]
            horizontal[y][u] = sum
        }
        var k = 0
        for (v in 0 until 8) for (u in 0 until 8) {
            var sum = 0.0
            for (y in 0 until 32) sum += horizontal[y][u] * cosY[v][y]
            coefficients[k++] = sum
        }
        val sorted = coefficients.copyOfRange(1, coefficients.size).sorted()
        val median = sorted[sorted.size / 2]
        var hash = 0L
        for (i in 0 until 64) if (coefficients[i] > median) hash = hash or (1L shl i)
        return hash
    }

    private fun hamming(a: Long, b: Long): Int = java.lang.Long.bitCount(a xor b)
}
