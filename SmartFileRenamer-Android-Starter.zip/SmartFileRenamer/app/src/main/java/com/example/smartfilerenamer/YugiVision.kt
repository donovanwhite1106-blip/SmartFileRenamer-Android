package com.example.smartfilerenamer

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import ai.onnxruntime.TensorInfo
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.nio.FloatBuffer
import java.security.MessageDigest
import java.util.concurrent.TimeUnit

/** Downloads the published YugiScan classifier assets once and verifies every asset by SHA-256. */
object YugiVision {
    private const val MODEL_URL = "https://github.com/LoganCRC/yugiscan-models/releases/download/V3.0/vit_classifier_int8.onnx"
    private const val LABELS_URL = "https://github.com/LoganCRC/yugiscan-models/releases/download/V3.0/card_labels.json"
    private const val MODEL_SHA = "bcde9c36204d391f44d11038a5dcd7742b99f1fcbdf26583670be29010cd8bd9"
    private const val LABELS_SHA = "4f558eeef0be9f530d1f4b58eab0520af21ef845c6482105161be98db290b90b"
    private val client = OkHttpClient.Builder().connectTimeout(30, TimeUnit.SECONDS).readTimeout(300, TimeUnit.SECONDS).callTimeout(360, TimeUnit.SECONDS).build()
    private val env: OrtEnvironment by lazy { OrtEnvironment.getEnvironment() }
    @Volatile private var session: OrtSession? = null
    @Volatile private var labels: List<String>? = null

    data class Match(val name: String, val confidence: Float)

    @Synchronized fun prepare(context: Context) {
        val model = File(context.filesDir, "vit_classifier_int8.onnx")
        val labelFile = File(context.filesDir, "card_labels.json")
        downloadVerified(model, MODEL_URL, MODEL_SHA)
        downloadVerified(labelFile, LABELS_URL, LABELS_SHA)
        labels = parseLabels(labelFile)
        if (session == null) session = env.createSession(model.absolutePath, OrtSession.SessionOptions())
    }

    fun classify(context: Context, uri: Uri): Match? {
        prepare(context)
        val bitmap = context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) } ?: return null
        try {
            val resized = Bitmap.createScaledBitmap(bitmap, 224, 224, true)
            val inputName = session!!.inputNames.firstOrNull() ?: return null
            val info = session!!.inputInfo[inputName]?.info as? TensorInfo ?: return null
            val shape = info.shape
            val nhwc = shape.size == 4 && shape[3] == 3L
            val height = if (shape.size == 4 && shape[2] > 0) shape[2].toInt() else 224
            val width = if (shape.size == 4 && (nhwc || shape[3] > 0)) (if (nhwc) shape[1] else shape[3]).toInt() else 224
            val image = if (width == 224 && height == 224) resized else Bitmap.createScaledBitmap(resized, width, height, true)
            val values = FloatArray(3 * width * height)
            for (y in 0 until height) for (x in 0 until width) {
                val pixel = image.getPixel(x, y)
                val rgb = intArrayOf((pixel shr 16) and 255, (pixel shr 8) and 255, pixel and 255)
                for (c in 0..2) {
                    // ViT image processors commonly scale [0,1] then normalize with mean/std 0.5.
                    val v = (rgb[c] / 255f - 0.5f) / 0.5f
                    val index = if (nhwc) (y * width + x) * 3 + c else c * width * height + y * width + x
                    values[index] = v
                }
            }
            val inputShape = when (shape.size) { 4 -> if (nhwc) longArrayOf(1, height.toLong(), width.toLong(), 3) else longArrayOf(1, 3, height.toLong(), width.toLong()); else -> longArrayOf(1, 3, height.toLong(), width.toLong()) }
            val tensor = OnnxTensor.createTensor(env, FloatBuffer.wrap(values), inputShape)
            tensor.use {
                session!!.run(mapOf(inputName to tensor)).use { result ->
                    val output = result.get(0).value ?: return null
                    val scores = flatten(output)
                    if (scores.isEmpty()) return null
                    val best = scores.indices.maxByOrNull { scores[it] } ?: return null
                    val probabilities = if (scores.any { it < 0f || it > 1f }) softmax(scores) else scores
                    val confidence = probabilities.getOrElse(best) { 0f }
                    val label = labels?.getOrNull(best)?.trim().orEmpty()
                    if (label.isBlank()) return null
                    return Match(label, confidence)
                }
            }
        } finally { if (!bitmap.isRecycled) bitmap.recycle() }
    }

    private fun flatten(value: Any): FloatArray {
        val out = ArrayList<Float>()
        fun walk(v: Any?) {
            when (v) {
                is FloatArray -> v.forEach(out::add)
                is Array<*> -> v.forEach(::walk)
                is Number -> out.add(v.toFloat())
            }
        }
        walk(value)
        return out.toFloatArray()
    }
    private fun softmax(a: FloatArray): FloatArray {
        val max = a.maxOrNull() ?: 0f
        val ex = a.map { kotlin.math.exp((it - max).toDouble()).toFloat() }
        val sum = ex.sum().coerceAtLeast(1e-20f)
        return ex.map { it / sum }.toFloatArray()
    }
    private fun parseLabels(file: File): List<String> {
        val text = file.readText(Charsets.UTF_8)
        val root = org.json.JSONTokener(text).nextValue()
        val values = when (root) {
            is JSONArray -> (0 until root.length()).map { root.optString(it) }
            is JSONObject -> {
                val candidate = root.optJSONArray("labels") ?: root.optJSONArray("classes") ?: root.optJSONArray("data")
                if (candidate != null) (0 until candidate.length()).map { candidate.optString(it) }
                else root.keys().asSequence().mapNotNull { key ->
                    val v = root.opt(key)
                    when (v) { is String -> v; is JSONObject -> v.optString("name").takeIf { it.isNotBlank() }; else -> null }
                }.toList()
            }
            else -> emptyList()
        }
        if (values.isEmpty()) throw IllegalStateException("The card label file has an unsupported or empty format.")
        return values
    }
    private fun downloadVerified(target: File, url: String, expected: String) {
        if (target.exists() && sha256(target) == expected) return
        val temp = File(target.parentFile, target.name + ".download")
        val request = Request.Builder().url(url).header("User-Agent", "SmartFileRenamer-Android").build()
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) throw IllegalStateException("Model download failed (${response.code}).")
            val body = response.body ?: throw IllegalStateException("Model download returned no data.")
            temp.outputStream().use { output -> body.byteStream().use { input -> input.copyTo(output) } }
        }
        if (sha256(temp) != expected) { temp.delete(); throw IllegalStateException("Downloaded ${target.name} failed its SHA-256 check; it was discarded.") }
        if (target.exists()) target.delete()
        if (!temp.renameTo(target)) throw IllegalStateException("Could not install downloaded ${target.name}.")
    }
    private fun sha256(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        file.inputStream().buffered().use { input ->
            val buffer = ByteArray(1024 * 1024)
            while (true) { val n = input.read(buffer); if (n < 0) break; digest.update(buffer, 0, n) }
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }
}
