package com.example.smartfilerenamer

import android.content.Context
import android.net.Uri
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.label.ImageLabeling
import com.google.mlkit.vision.label.defaults.ImageLabelerOptions
import java.io.IOException
import java.util.Locale

/** Free on-device image labeling fallback. Image bytes stay on the device. */
object OnDeviceImageNameResolver {
    private val generic = setOf("object", "product", "material", "font", "line", "pattern", "text", "screenshot", "image", "photograph", "photo", "picture")

    fun suggestBaseName(context: Context, uri: Uri): String? {
        val image = try { InputImage.fromFilePath(context, uri) }
        catch (e: Exception) { throw IOException("Could not open image for on-device recognition: ${e.message ?: e.javaClass.simpleName}", e) }
        val labeler = ImageLabeling.getClient(ImageLabelerOptions.Builder().setConfidenceThreshold(0.50f).build())
        return try {
            val labels = Tasks.await(labeler.process(image))
            val useful = labels.asSequence()
                .filter { it.confidence >= 0.50f }
                .map { it.text.trim() }
                .filter { it.length >= 3 && it.lowercase(Locale.ROOT) !in generic }
                .distinctBy { it.lowercase(Locale.ROOT) }
                .take(2)
                .toList()
            if (useful.isEmpty()) null else useful.joinToString(" ") { label ->
                label.split(Regex("\\s+")).joinToString(" ") { word -> word.replaceFirstChar { if (it.isLowerCase()) it.titlecase(Locale.ROOT) else it.toString() } }
            }.take(90)
        } catch (e: Exception) {
            throw IOException("On-device image recognition failed: ${e.cause?.message ?: e.message ?: e.javaClass.simpleName}", e)
        } finally {
            labeler.close()
        }
    }
}
