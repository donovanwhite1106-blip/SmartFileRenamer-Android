package com.example.smartfilerenamer

import android.content.Context
import android.net.Uri
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.jsoup.Jsoup
import java.io.IOException
import java.util.Locale
import java.util.concurrent.TimeUnit

/** Experimental Google Lens web upload. This uses an undocumented endpoint and may stop working. */
object GoogleLensNameResolver {
    private val client = OkHttpClient.Builder()
        .connectTimeout(25, TimeUnit.SECONDS)
        .readTimeout(45, TimeUnit.SECONDS)
        .writeTimeout(45, TimeUnit.SECONDS)
        .callTimeout(60, TimeUnit.SECONDS)
        .followRedirects(true)
        .build()
    private val generic = setOf("google lens", "google", "search", "images", "image search", "visual matches", "results", "lens")
    private val badChars = Regex("""[\\/:*?\"<>|\p{Cntrl}]""")
    private val spaces = Regex("\\s+")

    fun suggestBaseName(context: Context, uri: Uri): String? {
        val bytes = context.contentResolver.openInputStream(uri)?.use { input ->
            val out = java.io.ByteArrayOutputStream()
            val buffer = ByteArray(16 * 1024)
            var total = 0
            while (true) {
                val n = input.read(buffer)
                if (n < 0) break
                total += n
                if (total > 12 * 1024 * 1024) throw IOException("Image is larger than 12 MB; Google Lens lookup skipped.")
                out.write(buffer, 0, n)
            }
            out.toByteArray()
        } ?: throw IOException("Android could not read this image.")
        if (bytes.isEmpty()) throw IOException("Image file is empty.")
        val mime = context.contentResolver.getType(uri)?.takeIf { it.startsWith("image/") } ?: "image/jpeg"
        val body = MultipartBody.Builder().setType(MultipartBody.FORM)
            .addFormDataPart("encoded_image", "image", bytes.toRequestBody(mime.toMediaType()))
            .build()
        val request = Request.Builder()
            .url("https://lens.google.com/v3/upload")
            .header("User-Agent", "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/126.0.0.0 Mobile Safari/537.36")
            .header("Origin", "https://lens.google.com")
            .header("Referer", "https://lens.google.com/")
            .post(body)
            .build()
        val html = client.newCall(request).execute().use { response ->
            val text = response.body?.string().orEmpty()
            if (!response.isSuccessful) throw IOException("Google Lens upload failed (${response.code}); leaving the original name unchanged.")
            if (text.isBlank()) throw IOException("Google Lens returned an empty page.")
            text
        }
        val doc = Jsoup.parse(html)
        val candidates = mutableListOf<String>()
        doc.select("meta[property=og:title], meta[name=title]").forEach { it.attr("content").takeIf(String::isNotBlank)?.let(candidates::add) }
        doc.select("h1, h2, a[href]").take(120).forEach { el ->
            val t = el.text().trim()
            if (t.length in 5..100) candidates.add(t)
        }
        doc.select("script").forEach { script ->
            val t = script.data()
            Regex("""\"(?:title|text|query)\"\s*:\s*\"([^\"]{5,100})\""", RegexOption.IGNORE_CASE)
                .findAll(t).take(30).forEach { candidates.add(it.groupValues[1].replace("\\u003c", "<").replace("\\u003e", ">")) }
        }
        for (raw in candidates) {
            val cleaned = clean(raw) ?: continue
            // Refuse page chrome and overly generic names; caller will leave the file untouched if nothing useful remains.
            if (cleaned.lowercase(Locale.ROOT) !in generic && cleaned.split(' ').size >= 2) return cleaned
        }
        return null
    }

    private fun clean(raw: String): String? {
        val value = spaces.replace(raw.replace(badChars, " ").replace('_', ' '), " ").trim(' ', '.', '-', '_')
            .take(100).trim()
        if (value.length < 5 || value.lowercase(Locale.ROOT) in generic) return null
        if (value.contains("Google Lens", ignoreCase = true) && value.length < 25) return null
        return value.replace(Regex("[. ]+$"), "").replaceFirstChar { if (it.isLowerCase()) it.titlecase(Locale.ROOT) else it.toString() }
    }
}
