package com.example.smartfilerenamer

import android.content.pm.ServiceInfo
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.net.Uri
import android.os.Build
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import androidx.core.app.NotificationCompat
import androidx.documentfile.provider.DocumentFile
import androidx.work.CoroutineWorker
import androidx.work.ForegroundInfo
import androidx.work.WorkerParameters
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Processes every accessible file in the selected documents, including nested folders.
 * There is deliberately no fixed file-count cap. Per-file errors are recorded and do not
 * stop the rest of the batch. */
class RenameWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    private val channelId = "renamer_jobs"
    private val progressId = 4102
    private val resultId = 4103

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        createChannel()
        val jobKey = inputData.getString("jobKey")
        val preferences = applicationContext.getSharedPreferences("smart_renamer", Context.MODE_PRIVATE)
        val savedUris = jobKey?.let { preferences.getString(it, null) }
        val rawUris = savedUris?.split("\n")?.filter { it.isNotBlank() }?.toTypedArray() ?: emptyArray()
        if (rawUris.isEmpty()) {
            val msg = "Nothing selected. Return to the app and select files or a folder."
            notifyResult("Nothing to rename", msg)
            return@withContext Result.failure(androidx.work.workDataOf("error" to msg))
        }

        var renamed = 0
        var unchanged = 0
        var failed = 0
        var processed = 0
        val files = mutableListOf<DocumentFile>()
        val fileUris = mutableSetOf<String>()
        val visitedUris = mutableSetOf<String>()
        val scanWarnings = mutableListOf<String>()
        val failures = mutableListOf<String>()

        try {
            // Start foreground progress before the scan so long folder walks remain visible.
            runCatching { setForeground(buildForegroundInfo("Scanning selected folders…", 0, true)) }
            rawUris.forEach { raw ->
                if (isStopped) return@withContext Result.failure(androidx.work.workDataOf("message" to "Cancelled while scanning"))
                val uri = Uri.parse(raw)
                try {
                    if (DocumentsContract.isTreeUri(uri)) {
                        val root = DocumentFile.fromTreeUri(applicationContext, uri)
                        if (root != null) collect(root, files, fileUris, visitedUris, scanWarnings)
                        else scanWarnings.add("Could not open a selected folder; check its permissions.")
                    } else {
                        val file = DocumentFile.fromSingleUri(applicationContext, uri)
                        if (file != null && !file.isDirectory) {
                            if (fileUris.add(file.uri.toString())) files.add(file)
                        } else {
                            scanWarnings.add("A selected item could not be read as a file.")
                        }
                    }
                } catch (e: Exception) {
                    scanWarnings.add("Could not scan selected item: ${describe(e)}")
                }
            }

            if (files.isEmpty()) {
                val details = buildString {
                    append("The folder scan returned 0 file entries. This can happen when Android's document provider reports unknown MIME types. ")
                    append("Re-select the folder using Pick folder and confirm access. ")
                    if (scanWarnings.isNotEmpty()) append("Scan details: ").append(scanWarnings.take(6).joinToString("; "))
                }
                notifyResult("No files found", details)
                return@withContext Result.failure(androidx.work.workDataOf("error" to details, "scanWarnings" to scanWarnings.size))
            }

            val total = files.size
            val processingStartedAt = android.os.SystemClock.elapsedRealtime()
            updateProgress(processed, total, renamed, unchanged, failed, "Identifying images and renaming files…")
            files.forEachIndexed { index, file ->
                if (isStopped) {
                    val stopped = "Cancelled after $processed of $total files."
                    notifyResult("Rename cancelled", "$stopped Renamed $renamed; failed $failed.")
                    return@withContext Result.failure(androidx.work.workDataOf("message" to stopped, "processed" to processed, "total" to total))
                }

                val oldName = runCatching { file.name }.getOrNull()
                try {
                    if (oldName.isNullOrBlank() || file.isDirectory) {
                        failed++
                        if (failures.size < 8) failures.add("A selected item had no readable filename.")
                    } else {
                        val newName = if (GoogleImageNameResolver.isImage(oldName)) {
                            // Try the experimental Google Lens web-upload flow first. If it fails or
                            // yields no specific label, fall back to on-device ML Kit. No paid Vision API is called.
                            val lensGuess = runCatching {
                                GoogleLensNameResolver.suggestBaseName(applicationContext, file.uri)
                            }.getOrNull()
                            val localGuess = if (lensGuess.isNullOrBlank()) runCatching {
                                OnDeviceImageNameResolver.suggestBaseName(applicationContext, file.uri)
                            }.getOrNull() else null
                            val identifiedBase = lensGuess ?: localGuess
                                ?: throw java.io.IOException("Google Lens did not return a usable match and on-device recognition found no useful label; original name kept.")
                            val extension = oldName.substringAfterLast('.', "").takeIf { it.isNotBlank() && !oldName.endsWith('.') }
                            if (extension == null) identifiedBase else "$identifiedBase.$extension"
                        } else {
                            FileNameHeuristics.suggest(oldName)
                        }
                        if (newName.equals(oldName, ignoreCase = false)) {
                            unchanged++
                        } else {
                            val newUri = runCatching {
                                DocumentsContract.renameDocument(applicationContext.contentResolver, file.uri, newName)
                            }.getOrNull()

                            var verifiedName = newUri?.let { readDisplayName(it) }
                            if (verifiedName != newName) {
                                // Some providers behave better through DocumentFile.renameTo.
                                val fallback = runCatching { file.renameTo(newName) }.getOrDefault(false)
                                if (fallback) {
                                    verifiedName = readDisplayName(file.uri) ?: runCatching { file.name }.getOrNull()
                                }
                            }
                            if (verifiedName == newName) {
                                renamed++
                            } else {
                                failed++
                                if (failures.size < 8) failures.add("${oldName} → ${newName}: rename could not be verified (provider returned '${verifiedName ?: "no name"}')")
                            }
                        }
                    }
                } catch (e: SecurityException) {
                    failed++
                    if (failures.size < 8) failures.add("${oldName ?: "Unnamed file"}: permission denied")
                } catch (e: Exception) {
                    failed++
                    if (failures.size < 8) failures.add("${oldName ?: "Unnamed file"}: ${describe(e)}")
                }

                processed = index + 1
                val elapsedSeconds = ((android.os.SystemClock.elapsedRealtime() - processingStartedAt) / 1000L).coerceAtLeast(1L)
                val remainingSeconds = if (processed > 0) (elapsedSeconds.toDouble() / processed * (total - processed)).toLong() else 0L
                val eta = if (processed < total) " · about ${formatDuration(remainingSeconds)} left" else ""
                val message = "Processed $processed of $total · renamed $renamed · unchanged $unchanged · failed $failed$eta"
                updateProgress(processed, total, renamed, unchanged, failed, message)
                runCatching { setForeground(buildForegroundInfo(message, processed * 100 / total, false)) }
            }

            val warningNote = if (scanWarnings.isNotEmpty()) " Scan warnings: ${scanWarnings.size}." else ""
            val failureNote = if (failures.isNotEmpty()) " Examples: ${failures.take(3).joinToString(" | ")}" else ""
            val summary = "Finished $processed of $total files. Renamed $renamed; unchanged $unchanged; failed $failed.$warningNote$failureNote"
            notifyResult("Smart File Renamer finished", summary)
            val output = androidx.work.workDataOf(
                "message" to summary,
                "renamed" to renamed,
                "unchanged" to unchanged,
                "failed" to failed,
                "processed" to processed,
                "total" to total,
                "scanWarnings" to scanWarnings.size,
                "failureExamples" to failures.take(8).joinToString("\n")
            )
            // A completed batch is success even if individual files failed; the final report
            // tells the user exactly how many worked and how many did not.
            Result.success(output)
        } catch (e: Exception) {
            val message = "The job stopped unexpectedly after $processed files: ${describe(e)}"
            notifyResult("Rename job stopped", message)
            Result.failure(androidx.work.workDataOf("error" to message, "processed" to processed, "renamed" to renamed, "failed" to failed))
        }
    }

    private fun collect(
        item: DocumentFile,
        output: MutableList<DocumentFile>,
        fileUris: MutableSet<String>,
        visitedUris: MutableSet<String>,
        warnings: MutableList<String>
    ) {
        val key = item.uri.toString()
        if (!visitedUris.add(key)) return
        try {
            if (item.isDirectory) {
                val children = item.listFiles()
                for (child in children) {
                    try {
                        collect(child, output, fileUris, visitedUris, warnings)
                    } catch (e: Exception) {
                        warnings.add("Could not inspect ${child.name ?: "a folder item"}: ${describe(e)}")
                    }
                }
            } else if (fileUris.add(key)) {
                output.add(item)
            }
        } catch (e: Exception) {
            warnings.add("Could not read ${item.name ?: "a folder"}: ${describe(e)}")
        }
    }

    private suspend fun updateProgress(processed: Int, total: Int, renamed: Int, unchanged: Int, failed: Int, message: String) {
        val percent = if (total > 0) processed * 100 / total else 0
        // Keep the structured progress for the app, independently of notification updates.
        runCatching {
            setProgress(androidx.work.workDataOf(
                "progress" to percent,
                "message" to message,
                "total" to total,
                "processed" to processed,
                "renamed" to renamed,
                "unchanged" to unchanged,
                "failed" to failed
            ))
        }
    }

    private fun readDisplayName(uri: Uri): String? = try {
        applicationContext.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) cursor.getString(0) else null
        } ?: runCatching { DocumentFile.fromSingleUri(applicationContext, uri)?.name }.getOrNull()
    } catch (_: Exception) {
        runCatching { DocumentFile.fromSingleUri(applicationContext, uri)?.name }.getOrNull()
    }

    private fun describe(e: Exception): String = e.message?.takeIf { it.isNotBlank() } ?: e.javaClass.simpleName

    private fun formatDuration(seconds: Long): String = when {
        seconds < 60 -> "${seconds.coerceAtLeast(1)}s"
        seconds < 3600 -> "${seconds / 60}m ${seconds % 60}s"
        else -> "${seconds / 3600}h ${(seconds % 3600) / 60}m"
    }

    private fun createChannel() {
        val manager = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            manager.createNotificationChannel(NotificationChannel(channelId, "File renaming progress", NotificationManager.IMPORTANCE_LOW))
        }
    }

    private fun buildForegroundInfo(message: String, progress: Int, indeterminate: Boolean): ForegroundInfo {
        val notification = NotificationCompat.Builder(applicationContext, channelId)
            .setContentTitle("Smart File Renamer")
            .setContentText(message)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setOnlyAlertOnce(true)
            .setOngoing(true)
            .setProgress(100, progress.coerceIn(0, 100), indeterminate)
            .build()
        return ForegroundInfo(progressId, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
    }

    private fun notifyResult(title: String, message: String) {
        val manager = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(resultId, NotificationCompat.Builder(applicationContext, channelId)
            .setContentTitle(title)
            .setContentText(message.take(200))
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setSmallIcon(android.R.drawable.stat_sys_download_done)
            .setAutoCancel(true)
            .build())
    }
}

object FileNameHeuristics {
    private val badChars = Regex("""[\\/:*?"<>|\p{Cntrl}]""")
    private val spaces = Regex("\\s+")

    /** Non-image files get conservative cleanup only; image names come from Google Vision. */
    fun suggest(original: String): String {
        val ext = original.substringAfterLast('.', "").takeIf { it.isNotBlank() && !original.endsWith('.') }
        val base = if (ext == null) original else original.dropLast(ext.length + 1)
        val cleaned = spaces.replace(base.replace('_', ' ').replace('-', ' ').replace(badChars, " "), " ").trim()
        val safe = cleaned.ifBlank { base.trim().ifBlank { "renamed file" } }.take(120).trim()
        return safe + if (ext != null) ".$ext" else ""
    }
}
