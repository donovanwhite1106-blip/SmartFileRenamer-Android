package com.example.smartfilerenamer

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.net.Uri
import android.os.Build
import android.provider.DocumentsContract
import androidx.core.app.NotificationCompat
import androidx.documentfile.provider.DocumentFile
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class RenameWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    private val channelId = "renamer_jobs"
    private val progressId = 4102
    private val resultId = 4103

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        createChannel()
        val rawUris = inputData.getStringArray("uris") ?: emptyArray()
        if (rawUris.isEmpty()) {
            notifyResult("Nothing selected", "Return to the app and select files or a folder.")
            return@withContext Result.failure()
        }

        var renamed = 0
        var unchanged = 0
        var failed = 0
        val failureExamples = mutableListOf<String>()
        val files = mutableListOf<DocumentFile>()
        val seen = mutableSetOf<String>()
        postProgress("Scanning selected items…", 0, 0, null)

        try {
            rawUris.forEach { raw ->
                val uri = Uri.parse(raw)
                if (DocumentsContract.isTreeUri(uri)) {
                    postProgress("Reading folder contents…", 0, 0, null)
                    val root = DocumentFile.fromTreeUri(applicationContext, uri)
                    if (root != null) collect(root, files, seen) else {
                        failed++
                        failureExamples.add("Could not open the selected folder")
                    }
                } else {
                    val file = DocumentFile.fromSingleUri(applicationContext, uri)
                    if (file != null && seen.add(file.uri.toString())) files.add(file) else {
                        failed++
                        failureExamples.add("Could not open a selected file")
                    }
                }
            }

            if (files.isEmpty()) {
                val reason = failureExamples.firstOrNull() ?: "No readable files were found in the selected folder. Try a normal writable folder such as Downloads."
                notifyResult("Nothing to rename", reason)
                return@withContext Result.failure(workDataOf("message" to reason))
            }

            val total = files.size
            val startMs = System.currentTimeMillis()
            postProgress("Found $total files. Starting…", 0, total, 0)

            files.forEachIndexed { index, file ->
                if (isStopped) {
                    notifyResult("Renaming stopped", "Processed $index of $total files before the job stopped.")
                    return@withContext Result.failure()
                }
                try {
                    val oldName = file.name
                    if (oldName.isNullOrBlank() || !file.isFile) {
                        unchanged++
                    } else {
                        val newName = FileNameHeuristics.suggest(oldName)
                        if (newName == oldName) {
                            unchanged++
                        } else {
                            val renamedUri = try {
                                DocumentsContract.renameDocument(applicationContext.contentResolver, file.uri, newName)
                            } catch (_: Exception) { null }
                            val success = renamedUri != null || file.renameTo(newName)
                            if (success) renamed++ else {
                                failed++
                                if (failureExamples.size < 3) failureExamples.add("$oldName: storage provider refused the rename")
                            }
                        }
                    }
                } catch (_: SecurityException) {
                    failed++
                    if (failureExamples.size < 3) failureExamples.add("${file.name ?: "File"}: permission denied")
                } catch (e: Exception) {
                    failed++
                    if (failureExamples.size < 3) failureExamples.add("${file.name ?: "File"}: ${e.message ?: "rename error"}")
                }

                val done = index + 1
                val percent = done * 100 / total
                val elapsed = (System.currentTimeMillis() - startMs).coerceAtLeast(1)
                val etaMs = if (done < total) (elapsed.toDouble() / done * (total - done)).toLong() else 0L
                val eta = if (done >= total) "Finishing…" else "~${formatDuration(etaMs)} left"
                val message = "$done of $total files completed · $eta"
                setProgress(workDataOf("progress" to percent, "message" to message, "completed" to done, "total" to total))
                postProgress(message, done, total, percent)
            }

            val summary = "Renamed $renamed · unchanged $unchanged · failed $failed"
            val details = if (failureExamples.isEmpty()) summary else "$summary. Details: ${failureExamples.joinToString("; ")}"
            notifyResult("Smart File Renamer finished", details)
            if (renamed == 0 && failed > 0) Result.failure(workDataOf("message" to details, "renamed" to renamed, "failed" to failed))
            else Result.success(workDataOf("message" to details, "renamed" to renamed, "failed" to failed))
        } catch (e: Exception) {
            val message = e.message ?: e.javaClass.simpleName
            notifyResult("Rename job failed", "Could not process the selection: $message")
            Result.failure(workDataOf("error" to message))
        }
    }

    private fun collect(item: DocumentFile, output: MutableList<DocumentFile>, seen: MutableSet<String>) {
        if (item.isDirectory) {
            item.listFiles().forEach { child -> collect(child, output, seen) }
        } else if (item.isFile && seen.add(item.uri.toString())) output.add(item)
    }

    private fun createChannel() {
        val manager = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            manager.createNotificationChannel(NotificationChannel(channelId, "File renaming progress", NotificationManager.IMPORTANCE_LOW))
        }
    }

    private fun postProgress(message: String, done: Int, total: Int, percent: Int?) {
        val builder = NotificationCompat.Builder(applicationContext, channelId)
            .setContentTitle("Smart File Renamer")
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setOnlyAlertOnce(true)
            .setOngoing(true)
        if (percent == null || total == 0) builder.setProgress(0, 0, true)
        else builder.setProgress(100, percent.coerceIn(0, 100), false)
        val manager = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(progressId, builder.build())
    }

    private fun notifyResult(title: String, message: String) {
        val manager = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.cancel(progressId)
        manager.notify(resultId, NotificationCompat.Builder(applicationContext, channelId)
            .setContentTitle(title).setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setSmallIcon(android.R.drawable.stat_sys_download_done).setAutoCancel(true).build())
    }

    private fun formatDuration(ms: Long): String {
        val seconds = (ms / 1000).coerceAtLeast(1)
        return if (seconds < 60) "${seconds}s" else "${seconds / 60}m ${seconds % 60}s"
    }
}

object FileNameHeuristics {
    private val badChars = Regex("""[\\/:*?"<>|\p{Cntrl}]""")
    fun suggest(original: String): String {
        val ext = original.substringAfterLast('.', "").takeIf { it.isNotBlank() && !original.endsWith('.') }
        val base = if (ext == null) original else original.dropLast(ext.length + 1)
        val cleaned = base.replace('_', ' ').replace('-', ' ')
            .replace(Regex("""\s+"""), " ").trim().replace(badChars, "")
        var safe = cleaned.ifBlank { "renamed file" }.take(120).trim()
        if (safe.equals(base, ignoreCase = false)) {
            val lower = (ext ?: "").lowercase()
            val prefix = when (lower) {
                "jpg", "jpeg", "png", "gif", "webp", "heic", "bmp" -> "Image"
                "pdf", "doc", "docx", "txt", "rtf", "odt" -> "Document"
                "mp4", "mov", "mkv", "avi", "webm" -> "Video"
                "mp3", "wav", "m4a", "flac", "ogg" -> "Audio"
                "zip", "7z", "rar", "tar", "gz" -> "Archive"
                else -> "File"
            }
            if (!safe.startsWith("$prefix ")) safe = "$prefix $safe"
        }
        return safe + if (ext != null) ".$ext" else ""
    }
}
