package com.example.smartfilerenamer

import android.content.pm.ServiceInfo
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.net.Uri
import android.os.Build
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import androidx.core.app.NotificationCompat
import androidx.documentfile.provider.DocumentFile
import androidx.work.CoroutineWorker
import androidx.work.ForegroundInfo
import androidx.work.WorkerParameters
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Processes every accessible file in the selected documents, including nested folders.
 * There is deliberately no fixed file-count cap. Per-file errors are recorded and do not
 * stop the rest of the batch. */
class RenameWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    private val channelId = "renamer_jobs"
    private val progressId = 4102
    private val resultId = 4103

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        createChannel()
        val jobKey = inputData.getString("jobKey")
        val preferences = applicationContext.getSharedPreferences("smart_renamer", Context.MODE_PRIVATE)
        val visionApiKey = preferences.getString("google_vision_api_key", "").orEmpty().trim()
        val previewOnly = preferences.getBoolean("preview_only", true)
        val savedUris = jobKey?.let { preferences.getString(it, null) }
        val rawUris = savedUris?.split("\n")?.filter { it.isNotBlank() }?.toTypedArray() ?: emptyArray()
        if (rawUris.isEmpty()) {
            val msg = "Nothing selected. Return to the app and select files or a folder."
            notifyResult("Nothing to rename", msg)
            return@withContext Result.failure(androidx.work.workDataOf("error" to msg))
        }

        var renamed = 0
        var unchanged = 0
        var failed = 0
        var processed = 0
        var catalogError: Exception? = null
        val files = mutableListOf<DocumentFile>()
        val fileUris = mutableSetOf<String>()
        val visitedUris = mutableSetOf<String>()
        val scanWarnings = mutableListOf<String>()
        val failures = mutableListOf<String>()

        try {
            // Start foreground progress before the scan so long folder walks remain visible.
            runCatching { setForeground(buildForegroundInfo("Scanning selected folders…", 0, true)) }
            rawUris.forEach { raw ->
                if (isStopped) return@withContext Result.failure(androidx.work.workDataOf("message" to "Cancelled while scanning"))
                val uri = Uri.parse(raw)
                try {
                    if (DocumentsContract.isTreeUri(uri)) {
                        val root = DocumentFile.fromTreeUri(applicationContext, uri)
                        if (root != null) collect(root, files, fileUris, visitedUris, scanWarnings)
                        else scanWarnings.add("Could not open a selected folder; check its permissions.")
                    } else {
                        val file = DocumentFile.fromSingleUri(applicationContext, uri)
                        if (file != null && !file.isDirectory) {
                            if (fileUris.add(file.uri.toString())) files.add(file)
                        } else {
                            scanWarnings.add("A selected item could not be read as a file.")
                        }
                    }
                } catch (e: Exception) {
                    scanWarnings.add("Could not scan selected item: ${describe(e)}")
                }
            }

            if (files.isEmpty()) {
                val details = buildString {
                    append("The folder scan returned 0 file entries. This can happen when Android's document provider reports unknown MIME types. ")
                    append("Re-select the folder using Pick folder and confirm access. ")
                    if (scanWarnings.isNotEmpty()) append("Scan details: ").append(scanWarnings.take(6).joinToString("; "))
                }
                notifyResult("No files found", details)
                return@withContext Result.failure(androidx.work.workDataOf("error" to details, "scanWarnings" to scanWarnings.size))
            }

            val total = files.size
            // Load the card catalog once for the entire batch. If the first download fails, do not
            // repeatedly hit the API for thousands of files and never fall back to generic labels.
            if (files.any { YgoProDeckResolver.isImage(it.name.orEmpty()) }) {
                try {
                    YgoProDeckResolver.prepare(applicationContext)
                } catch (e: Exception) {
                    catalogError = e
                    if (failures.size < 8) failures.add("Card catalog unavailable: ${describe(e)}")
                }
            }
            val generatedNames = mutableMapOf<String, Int>()
            val processingStartedAt = android.os.SystemClock.elapsedRealtime()
            updateProgress(processed, total, renamed, unchanged, failed, if (previewOnly) "Previewing card names without changing files…" else "Matching card names and renaming files…")
            files.forEachIndexed { index, file ->
                if (isStopped) {
                    val stopped = "Cancelled after $processed of $total files."
                    notifyResult("Rename cancelled", "$stopped Renamed $renamed; failed $failed.")
                    return@withContext Result.failure(androidx.work.workDataOf("message" to stopped, "processed" to processed, "total" to total))
                }

                val oldName = runCatching { file.name }.getOrNull()
                try {
                    if (oldName.isNullOrBlank() || file.isDirectory) {
                        failed++
                        if (failures.size < 8) failures.add("A selected item had no readable filename.")
                    } else {
                        val newName: String? = if (YgoProDeckResolver.isImage(oldName)) {
                            if (catalogError != null) {
                                // Fail closed: do not mutate anything if the reference catalog is unavailable.
                                unchanged++
                                null
                            } else {
                                val identifiedBase = YgoProDeckResolver.resolveBaseName(applicationContext, oldName)
                                if (identifiedBase == null) {
                                    // Unknown numeric IDs and non-matching names are not guessed.
                                    unchanged++
                                    null
                                } else {
                                    val extension = oldName.substringAfterLast('.', "").takeIf { it.isNotBlank() && !oldName.endsWith('.') }
                                    val baseName = if (extension == null) identifiedBase else "$identifiedBase.$extension"
                                    val count = (generatedNames[baseName.lowercase()] ?: 0) + 1
                                    generatedNames[baseName.lowercase()] = count
                                    if (count == 1) baseName else {
                                        val stem = baseName.substringBeforeLast('.', baseName)
                                        val ext = baseName.substringAfterLast('.', "").takeIf { it.isNotBlank() && !baseName.endsWith('.') }
                                        val uniqueStem = "$stem ($count)"
                                        if (ext == null) uniqueStem else "$uniqueStem.$ext"
                                    }
                                }
                            }
                        } else {
                            FileNameHeuristics.suggest(oldName)
                        }
                        if (newName == null) {
                            // Kept unchanged because there is no safe, confirmed card identity.
                        } else if (previewOnly) {
                            if (newName == oldName) unchanged++ else renamed++ // In preview mode, this is the number that WOULD be renamed.
                        } else if (newName.equals(oldName, ignoreCase = false)) {
                            unchanged++
                        } else {
                            // Keep both the original and provider-returned URI: many SAF providers
                            // issue a NEW document URI after renameDocument(), making the original
                            // URI stale. Verify against the returned URI first, then re-query the
                            // original URI after the DocumentFile fallback.
                            val originalUri = file.uri
                            val providerUri = runCatching {
                                DocumentsContract.renameDocument(applicationContext.contentResolver, originalUri, newName)
                            }.getOrNull()
                            var verifiedName = providerUri?.let { readDisplayName(it) }

                            if (verifiedName != newName) {
                                // DocumentFile's implementation can use a provider-specific rename
                                // path. Recreate the DocumentFile after the attempt because some
                                // providers mutate its internal URI during renameTo().
                                runCatching { file.renameTo(newName) }
                                val refreshedUri = runCatching { file.uri }.getOrNull()
                                verifiedName = listOfNotNull(providerUri, refreshedUri, originalUri)
                                    .distinct()
                                    .asSequence()
                                    .mapNotNull { uri -> readDisplayName(uri) }
                                    .firstOrNull { it == newName }
                                    ?: refreshedUri?.let { readDisplayName(it) }
                                    ?: providerUri?.let { readDisplayName(it) }
                                    ?: originalUri.let { readDisplayName(it) }
                            }
                            if (verifiedName == newName) {
                                renamed++
                            } else {
                                failed++
                                if (failures.size < 8) failures.add("${oldName} → ${newName}: rename could not be verified (provider reported '${verifiedName ?: "no name"}'). Check that the selected storage provider allows renaming.")
                            }
                        }
                    }
                } catch (e: SecurityException) {
                    failed++
                    if (failures.size < 8) failures.add("${oldName ?: "Unnamed file"}: permission denied")
                } catch (e: Exception) {
                    failed++
                    if (failures.size < 8) failures.add("${oldName ?: "Unnamed file"}: ${describe(e)}")
                }

                processed = index + 1
                val elapsedSeconds = ((android.os.SystemClock.elapsedRealtime() - processingStartedAt) / 1000L).coerceAtLeast(1L)
                val remainingSeconds = if (processed > 0) (elapsedSeconds.toDouble() / processed * (total - processed)).toLong() else 0L
                val eta = if (processed < total) " · about ${formatDuration(remainingSeconds)} left" else ""
                val actionCount = if (previewOnly) "would rename $renamed" else "renamed $renamed"
                val message = "Processed $processed of $total · $actionCount · unchanged $unchanged · failed $failed$eta"
                updateProgress(processed, total, renamed, unchanged, failed, message)
                runCatching { setForeground(buildForegroundInfo(message, processed * 100 / total, false)) }
            }

            val warningNote = if (scanWarnings.isNotEmpty()) " Scan warnings: ${scanWarnings.size}." else ""
            val catalogNote = catalogError?.let { " Card catalog unavailable; no image files were changed. ${describe(it)}" }.orEmpty()
            val failureNote = if (failures.isNotEmpty()) " Examples: ${failures.take(3).joinToString(" | ")}" else ""
            val summary = if (previewOnly) {
                "PREVIEW ONLY — processed $processed of $total files. Would rename $renamed; unchanged $unchanged; failed $failed. No files were changed.$warningNote$catalogNote$failureNote"
            } else {
                "Finished $processed of $total files. Renamed $renamed; unchanged $unchanged; failed $failed.$warningNote$catalogNote$failureNote"
            }
            notifyResult(if (previewOnly) "Smart File Renamer preview finished" else "Smart File Renamer finished", summary)
            val output = androidx.work.workDataOf(
                "message" to summary,
                "renamed" to renamed,
                "unchanged" to unchanged,
                "failed" to failed,
                "processed" to processed,
                "total" to total,
                "scanWarnings" to scanWarnings.size,
                "failureExamples" to failures.take(8).joinToString("\n")
            )
            // A completed batch is success even if individual files failed; the final report
            // tells the user exactly how many worked and how many did not.
            Result.success(output)
        } catch (e: Exception) {
            val message = "The job stopped unexpectedly after $processed files: ${describe(e)}"
            notifyResult("Rename job stopped", message)
            Result.failure(androidx.work.workDataOf("error" to message, "processed" to processed, "renamed" to renamed, "failed" to failed))
        }
    }

    private fun collect(
        item: DocumentFile,
        output: MutableList<DocumentFile>,
        fileUris: MutableSet<String>,
        visitedUris: MutableSet<String>,
        warnings: MutableList<String>
    ) {
        val key = item.uri.toString()
        if (!visitedUris.add(key)) return
        try {
            if (item.isDirectory) {
                val children = item.listFiles()
                for (child in children) {
                    try {
                        collect(child, output, fileUris, visitedUris, warnings)
                    } catch (e: Exception) {
                        warnings.add("Could not inspect ${child.name ?: "a folder item"}: ${describe(e)}")
                    }
                }
            } else if (fileUris.add(key)) {
                output.add(item)
            }
        } catch (e: Exception) {
            warnings.add("Could not read ${item.name ?: "a folder"}: ${describe(e)}")
        }
    }

    private suspend fun updateProgress(processed: Int, total: Int, renamed: Int, unchanged: Int, failed: Int, message: String) {
        val percent = if (total > 0) processed * 100 / total else 0
        // Keep the structured progress for the app, independently of notification updates.
        runCatching {
            setProgress(androidx.work.workDataOf(
                "progress" to percent,
                "message" to message,
                "total" to total,
                "processed" to processed,
                "renamed" to renamed,
                "unchanged" to unchanged,
                "failed" to failed
            ))
        }
    }

    private fun readDisplayName(uri: Uri): String? = try {
        applicationContext.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                val column = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (column >= 0) cursor.getString(column) else null
            } else null
        } ?: runCatching { DocumentFile.fromSingleUri(applicationContext, uri)?.name }.getOrNull()
    } catch (_: Exception) {
        runCatching { DocumentFile.fromSingleUri(applicationContext, uri)?.name }.getOrNull()
    }

    private fun describe(e: Exception): String = e.message?.takeIf { it.isNotBlank() } ?: e.javaClass.simpleName

    private fun formatDuration(seconds: Long): String = when {
        seconds < 60 -> "${seconds.coerceAtLeast(1)}s"
        seconds < 3600 -> "${seconds / 60}m ${seconds % 60}s"
        else -> "${seconds / 3600}h ${(seconds % 3600) / 60}m"
    }

    private fun createChannel() {
        val manager = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            manager.createNotificationChannel(NotificationChannel(channelId, "File renaming progress", NotificationManager.IMPORTANCE_LOW))
        }
    }

    private fun buildForegroundInfo(message: String, progress: Int, indeterminate: Boolean): ForegroundInfo {
        val notification = NotificationCompat.Builder(applicationContext, channelId)
            .setContentTitle("Smart File Renamer")
            .setContentText(message)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setOnlyAlertOnce(true)
            .setOngoing(true)
            .setProgress(100, progress.coerceIn(0, 100), indeterminate)
            .build()
        return ForegroundInfo(progressId, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
    }

    private fun notifyResult(title: String, message: String) {
        val manager = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(resultId, NotificationCompat.Builder(applicationContext, channelId)
            .setContentTitle(title)
            .setContentText(message.take(200))
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setSmallIcon(android.R.drawable.stat_sys_download_done)
            .setAutoCancel(true)
            .build())
    }
}

object FileNameHeuristics {
    private val badChars = Regex("""[\\/:*?"<>|\p{Cntrl}]""")
    private val spaces = Regex("\\s+")

    /** Non-image files get conservative cleanup only; image names come from confirmed YGOPRODeck catalog matches. */
    fun suggest(original: String): String {
        val ext = original.substringAfterLast('.', "").takeIf { it.isNotBlank() && !original.endsWith('.') }
        val base = if (ext == null) original else original.dropLast(ext.length + 1)
        val cleaned = spaces.replace(base.replace('_', ' ').replace('-', ' ').replace(badChars, " "), " ").trim()
        val safe = cleaned.ifBlank { base.trim().ifBlank { "renamed file" } }.take(120).trim()
        return safe + if (ext != null) ".$ext" else ""
    }
}
