package com.example.smartfilerenamer

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.net.Uri
import android.os.Build
import android.provider.DocumentsContract
import androidx.core.app.NotificationCompat
import androidx.documentfile.provider.DocumentFile
import androidx.work.CoroutineWorker
import androidx.work.ForegroundInfo
import androidx.work.WorkerParameters
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class RenameWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    private val channelId = "renamer_jobs"
    private val progressId = 4102
    private val resultId = 4103

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        createChannel()
        val rawUris = inputData.getStringArray("uris") ?: emptyArray()
        if (rawUris.isEmpty()) {
            notifyResult("Nothing selected", "Return to the app and select files.")
            return@withContext Result.failure()
        }
        var renamed = 0
        var unchanged = 0
        var failed = 0
        try {
            setForeground(foregroundInfo("Preparing selected items…", 0, 0, true))
            val files = mutableListOf<DocumentFile>()
            val seen = mutableSetOf<String>()
            rawUris.forEach { raw ->
                val uri = Uri.parse(raw)
                if (DocumentsContract.isTreeUri(uri)) {
                    val root = DocumentFile.fromTreeUri(applicationContext, uri)
                    if (root != null) collect(root, files, seen) else failed++
                } else {
                    val file = DocumentFile.fromSingleUri(applicationContext, uri)
                    if (file != null && seen.add(file.uri.toString())) files.add(file) else failed++
                }
            }
            if (files.isEmpty()) {
                notifyResult("No files found", "The selected items were not accessible. Check storage permissions.")
                return@withContext Result.failure()
            }
            val total = files.size
            files.forEachIndexed { index, file ->
                if (isStopped) return@withContext Result.failure()
                try {
                    val oldName = file.name
                    if (oldName.isNullOrBlank() || !file.isFile) {
                        unchanged++
                    } else {
                        val newName = FileNameHeuristics.suggest(oldName)
                        if (newName == oldName) unchanged++
                        else if (file.renameTo(newName)) renamed++ else failed++
                    }
                } catch (_: SecurityException) { failed++ }
                catch (_: Exception) { failed++ }
                val done = index + 1
                val percent = done * 100 / total
                val message = "Processed $done of $total files"
                setProgress(workDataOf("progress" to percent, "message" to message))
                setForeground(foregroundInfo(message, percent, total, false))
            }
            val summary = "Renamed $renamed · unchanged $unchanged · failed $failed"
            notifyResult("Smart File Renamer finished", summary)
            if (renamed == 0 && failed > 0) Result.failure(workDataOf("message" to summary))
            else Result.success(workDataOf("message" to summary, "renamed" to renamed, "failed" to failed))
        } catch (e: Exception) {
            notifyResult("Rename job failed", e.message ?: "An unexpected error occurred. Check write access.")
            Result.failure(workDataOf("error" to (e.message ?: "Unknown error")))
        }
    }

    private fun collect(item: DocumentFile, output: MutableList<DocumentFile>, seen: MutableSet<String>) {
        if (item.isDirectory) {
            item.listFiles().forEach { child -> collect(child, output, seen) }
        } else if (item.isFile && seen.add(item.uri.toString())) output.add(item)
    }

    private fun createChannel() {
        val manager = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            manager.createNotificationChannel(NotificationChannel(channelId, "File renaming progress", NotificationManager.IMPORTANCE_LOW))
        }
    }

    private fun foregroundInfo(message: String, progress: Int, total: Int, indeterminate: Boolean): ForegroundInfo {
        val notification = NotificationCompat.Builder(applicationContext, channelId)
            .setContentTitle("Smart File Renamer")
            .setContentText(message)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setOnlyAlertOnce(true)
            .setOngoing(true)
            .setProgress(100, progress.coerceIn(0, 100), indeterminate)
            .build()
        return ForegroundInfo(progressId, notification)
    }

    private fun notifyResult(title: String, message: String) {
        val manager = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(resultId, NotificationCompat.Builder(applicationContext, channelId)
            .setContentTitle(title).setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setSmallIcon(android.R.drawable.stat_sys_download_done).setAutoCancel(true).build())
    }
}

object FileNameHeuristics {
    private val badChars = Regex("""[\\/:*?"<>|\p{Cntrl}]""")
    fun suggest(original: String): String {
        val ext = original.substringAfterLast('.', "").takeIf { it.isNotBlank() && !original.endsWith('.') }
        val base = if (ext == null) original else original.dropLast(ext.length + 1)
        val cleaned = base.replace('_', ' ').replace('-', ' ')
            .replace(Regex("""\s+"""), " ").trim().replace(badChars, "")
        var safe = cleaned.ifBlank { "renamed file" }.take(120).trim()
        // If the filename is already clean, apply a stable type prefix so the action still renames it.
        if (safe.equals(base, ignoreCase = false)) {
            val lower = (ext ?: "").lowercase()
            val prefix = when (lower) {
                "jpg", "jpeg", "png", "gif", "webp", "heic", "bmp" -> "Image"
                "pdf", "doc", "docx", "txt", "rtf", "odt" -> "Document"
                "mp4", "mov", "mkv", "avi", "webm" -> "Video"
                "mp3", "wav", "m4a", "flac", "ogg" -> "Audio"
                "zip", "7z", "rar", "tar", "gz" -> "Archive"
                else -> "File"
            }
            if (!safe.startsWith("$prefix ")) safe = "$prefix $safe"
        }
        return safe + if (ext != null) ".$ext" else ""
    }
}
