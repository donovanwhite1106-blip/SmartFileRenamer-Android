package com.example.smartfilerenamer

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.DocumentsContract
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.documentfile.provider.DocumentFile
import androidx.work.*
import java.util.concurrent.TimeUnit

class MainActivity : ComponentActivity() {
    private val selected = mutableStateListOf<Uri>()
    private var status by mutableStateOf("Choose files or a folder, then tap Rename selected items.")

    private val pickFiles = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == RESULT_OK) {
            val data = result.data
            val found = mutableListOf<Uri>()
            data?.clipData?.let { clip -> for (i in 0 until clip.itemCount) found += clip.getItemAt(i).uri }
            data?.data?.let { if (it !in found) found += it }
            found.forEach { uri ->
                val flags = (data?.flags ?: 0) and (Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
                try { if (flags != 0) contentResolver.takePersistableUriPermission(uri, flags) } catch (_: Exception) {}
                if (uri !in selected) selected.add(uri)
            }
            status = if (found.isEmpty()) "No files selected." else "${selected.size} item(s) selected."
        }
    }

    private val pickFolder = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        uri?.let {
            try { contentResolver.takePersistableUriPermission(it, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION) } catch (_: Exception) {}
            if (it !in selected) selected.add(it)
            val count = runCatching { folderFiles(it).size }.getOrDefault(0)
            status = if (count == 0) "Folder selected, but no readable files were found. Try a normal folder such as Downloads." else "Folder selected: $count file(s) found, including subfolders."
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 200)
        setContent {
            MaterialTheme {
                Surface(Modifier.fillMaxSize()) {
                    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("Smart File Renamer", style = MaterialTheme.typography.headlineMedium)
                        Text("Clean up filenames with a background progress notification.")
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = { launchFilePicker() }, modifier = Modifier.weight(1f)) { Text("Pick files") }
                            OutlinedButton(onClick = { pickFolder.launch(null) }, modifier = Modifier.weight(1f)) { Text("Pick folder") }
                        }
                        Text("Selected items: ${selected.size}", style = MaterialTheme.typography.titleMedium)
                        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            items(selected.toList()) { uri ->
                                val isTree = remember(uri) { DocumentsContract.isTreeUri(uri) }
                                val label = remember(uri) {
                                    runCatching {
                                        if (isTree) DocumentFile.fromTreeUri(this@MainActivity, uri)?.name
                                        else DocumentFile.fromSingleUri(this@MainActivity, uri)?.name
                                    }.getOrNull() ?: uri.lastPathSegment ?: uri.toString()
                                }
                                val children = remember(uri) { if (isTree) runCatching { folderFiles(uri).mapNotNull { it.name } }.getOrDefault(emptyList()) else emptyList() }
                                Card(Modifier.fillMaxWidth()) {
                                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                        Text(if (isTree) "Folder: $label" else label, style = MaterialTheme.typography.titleSmall, maxLines = 2)
                                        if (isTree) {
                                            Text(if (children.isEmpty()) "No readable files found" else "Contents: ${children.size} file(s)")
                                            children.take(20).forEach { child -> Text("• $child", style = MaterialTheme.typography.bodySmall, maxLines = 1) }
                                            if (children.size > 20) Text("…and ${children.size - 20} more", style = MaterialTheme.typography.bodySmall)
                                        }
                                    }
                                }
                            }
                        }
                        Text(status)
                        Button(onClick = { startRenameJob() }, enabled = selected.isNotEmpty(), modifier = Modifier.fillMaxWidth()) { Text("Rename selected items") }
                        OutlinedButton(onClick = { selected.clear(); status = "Selection cleared." }, modifier = Modifier.fillMaxWidth()) { Text("Clear selection") }
                        Text("Use a normal writable folder such as Downloads for the first test. Some cloud or protected storage providers do not allow renaming.", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }

    private fun folderFiles(treeUri: Uri): List<DocumentFile> {
        val root = DocumentFile.fromTreeUri(this, treeUri) ?: return emptyList()
        val result = mutableListOf<DocumentFile>()
        fun visit(item: DocumentFile) {
            if (item.isDirectory) item.listFiles().forEach { child -> visit(child) }
            else if (item.isFile) result.add(item)
        }
        visit(root)
        return result
    }

    private fun launchFilePicker() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        pickFiles.launch(intent)
    }

    private fun startRenameJob() {
        val request = OneTimeWorkRequestBuilder<RenameWorker>()
            .setInputData(workDataOf("uris" to selected.map { it.toString() }.toTypedArray()))
            .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 10, TimeUnit.SECONDS)
            .addTag("smart-renamer")
            .build()
        WorkManager.getInstance(this).enqueueUniqueWork("smart-renamer-${System.currentTimeMillis()}", ExistingWorkPolicy.KEEP, request)
        status = "Job queued. Watch the notification for files completed, total files, and estimated time remaining."
    }
}
