package com.example.smartfilerenamer

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.documentfile.provider.DocumentFile
import androidx.work.*
import java.util.concurrent.TimeUnit

class MainActivity : ComponentActivity() {
    private val selected = mutableStateListOf<Uri>()
    private var status by mutableStateOf("Choose files or a folder, then tap Rename selected items.")

    private val pickFiles = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == RESULT_OK) {
            val data = result.data
            val found = mutableListOf<Uri>()
            data?.clipData?.let { clip -> for (i in 0 until clip.itemCount) found += clip.getItemAt(i).uri }
            data?.data?.let { if (it !in found) found += it }
            found.forEach { uri ->
                val flags = (data?.flags ?: 0) and (Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
                try { contentResolver.takePersistableUriPermission(uri, flags) } catch (_: Exception) {}
                if (uri !in selected) selected.add(uri)
            }
            status = if (found.isEmpty()) "No files selected." else "${selected.size} item(s) selected."
        }
    }

    private val pickFolder = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        uri?.let {
            try { contentResolver.takePersistableUriPermission(it, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION) } catch (_: Exception) {}
            if (it !in selected) selected.add(it)
            status = "Folder selected. Files inside it and subfolders will be processed."
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 200)
        setContent {
            MaterialTheme {
                Surface(Modifier.fillMaxSize()) {
                    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("Smart File Renamer", style = MaterialTheme.typography.headlineMedium)
                        Text("Clean up filenames with a background progress notification.")
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = { launchFilePicker() }, modifier = Modifier.weight(1f)) { Text("Pick files") }
                            OutlinedButton(onClick = { pickFolder.launch(null) }, modifier = Modifier.weight(1f)) { Text("Pick folder") }
                        }
                        Text("Selected items: ${selected.size}", style = MaterialTheme.typography.titleMedium)
                        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            items(selected.toList()) { uri ->
                                val label = remember(uri) { runCatching { DocumentFile.fromSingleUri(this@MainActivity, uri)?.name }.getOrNull() ?: uri.lastPathSegment ?: uri.toString() }
                                Card(Modifier.fillMaxWidth()) { Text(label, Modifier.padding(12.dp), maxLines = 2) }
                            }
                        }
                        Text(status)
                        Button(onClick = { startRenameJob() }, enabled = selected.isNotEmpty(), modifier = Modifier.fillMaxWidth()) { Text("Rename selected items") }
                        OutlinedButton(onClick = { selected.clear(); status = "Selection cleared." }, modifier = Modifier.fillMaxWidth()) { Text("Clear selection") }
                        Text("Renaming requires write access from the storage provider. ZIP extraction/export and online identification are not included yet.", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }

    private fun launchFilePicker() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        pickFiles.launch(intent)
    }

    private fun startRenameJob() {
        val request = OneTimeWorkRequestBuilder<RenameWorker>()
            .setInputData(workDataOf("uris" to selected.map { it.toString() }.toTypedArray()))
            .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 10, TimeUnit.SECONDS)
            .addTag("smart-renamer")
            .build()
        WorkManager.getInstance(this).enqueueUniqueWork("smart-renamer-${System.currentTimeMillis()}", ExistingWorkPolicy.KEEP, request)
        status = "Job started. Check the notification shade for live progress and the final summary."
    }
}
