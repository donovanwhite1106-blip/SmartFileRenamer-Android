package com.example.smartfilerenamer

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.documentfile.provider.DocumentFile
import androidx.core.content.FileProvider
import androidx.work.*
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import java.util.concurrent.TimeUnit

class MainActivity : ComponentActivity() {
    private val selected = mutableStateListOf<Uri>()
    private var status by mutableStateOf("Choose files or a folder, then tap Rename selected items.")
    private var exporting by mutableStateOf(false)
    private var lastExportUri by mutableStateOf<Uri?>(null)
    private var showProgressPage by mutableStateOf(false)
    private var liveProgress by mutableStateOf(0)
    private var liveProgressMessage by mutableStateOf("No rename job is currently running.")
    private var liveJobState by mutableStateOf("No job started")
    private var liveProcessed by mutableIntStateOf(0)
    private var liveTotal by mutableIntStateOf(0)
    private var liveRenamed by mutableIntStateOf(0)
    private var liveUnchanged by mutableIntStateOf(0)
    private var liveFailed by mutableIntStateOf(0)

    private val createExport = registerForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { destination ->
        if (destination == null) {
            status = "Export cancelled."
        } else {
            exportSelected(destination)
        }
    }

    private val pickFiles = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        // Keep provider-specific failures from escaping the picker callback and crashing the Activity.
        try {
            if (result.resultCode == RESULT_OK) {
                val data = result.data
                val found = mutableListOf<Uri>()
                data?.clipData?.let { clip ->
                    for (i in 0 until clip.itemCount) {
                        runCatching { clip.getItemAt(i).uri }.getOrNull()?.let { if (it !in found) found.add(it) }
                    }
                }
                data?.data?.let { if (it !in found) found.add(it) }
                val flags = (data?.flags ?: 0) and (Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
                found.forEach { uri ->
                    if (flags != 0) runCatching { contentResolver.takePersistableUriPermission(uri, flags) }
                    if (uri !in selected) selected.add(uri)
                }
                runCatching { persistSelection() }
                status = if (found.isEmpty()) "No file URI was returned by Android. Try Pick files again." else "${selected.size} item(s) selected."
            }
        } catch (e: Exception) {
            status = "Could not add the selected file: ${e.message ?: e.javaClass.simpleName}. Try selecting it again."
        }
    }

    private val pickFolder = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        uri?.let {
            try { contentResolver.takePersistableUriPermission(it, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION) } catch (_: Exception) {}
            if (it !in selected) selected.add(it)
            persistSelection()
            status = "Folder selected. Files inside it and subfolders will be processed."
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 200)
        val prefs = getSharedPreferences("smart_renamer", MODE_PRIVATE)
        prefs.getString("selected_uris", null)?.split("\n")?.filter { it.isNotBlank() }?.forEach { raw ->
            runCatching { selected.add(Uri.parse(raw)) }
        }
        WorkManager.getInstance(this).getWorkInfosByTagLiveData("smart-renamer").observe(this) { infos ->
            val info = infos?.firstOrNull { !it.state.isFinished } ?: infos?.firstOrNull()
            if (info != null) {
                liveJobState = info.state.name.lowercase().replaceFirstChar { it.uppercase() }
                liveProgress = info.progress.getInt("progress", if (info.state == WorkInfo.State.SUCCEEDED) 100 else 0).coerceIn(0, 100)
                liveProcessed = info.progress.getInt("processed", info.outputData.getInt("processed", 0))
                liveTotal = info.progress.getInt("total", info.outputData.getInt("total", 0))
                liveRenamed = info.progress.getInt("renamed", info.outputData.getInt("renamed", 0))
                liveUnchanged = info.progress.getInt("unchanged", info.outputData.getInt("unchanged", 0))
                liveFailed = info.progress.getInt("failed", info.outputData.getInt("failed", 0))
                liveProgressMessage = info.progress.getString("message")
                    ?: info.outputData.getString("message")
                    ?: info.outputData.getString("error")
                    ?: when (info.state) {
                        WorkInfo.State.ENQUEUED -> "Rename job queued; waiting to start."
                        WorkInfo.State.RUNNING -> "Rename job is running. Scanning files may take a little while."
                        WorkInfo.State.SUCCEEDED -> "Rename job finished."
                        WorkInfo.State.FAILED -> "Rename job failed. Check the notification for details."
                        WorkInfo.State.CANCELLED -> "Rename job cancelled."
                        WorkInfo.State.BLOCKED -> "Rename job is waiting."
                    }
            }
        }
        setContent {
            MaterialTheme {
                Surface(Modifier.fillMaxSize()) {
                    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("Smart File Renamer", style = MaterialTheme.typography.headlineMedium)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = { showProgressPage = false }, modifier = Modifier.weight(1f)) { Text("Select Files") }
                            Button(onClick = { showProgressPage = true }, modifier = Modifier.weight(1f)) { Text("Currently Renaming") }
                        }
                        if (showProgressPage) {
                            Text("Currently Renaming", style = MaterialTheme.typography.titleLarge)
                            Text(liveJobState, style = MaterialTheme.typography.titleMedium)
                            LinearProgressIndicator(progress = { liveProgress / 100f }, modifier = Modifier.fillMaxWidth())
                            Text(if (liveTotal > 0) "$liveProcessed of $liveTotal files completed" else "Preparing file list…", style = MaterialTheme.typography.titleMedium)
                            Text("Renamed: $liveRenamed · Unchanged: $liveUnchanged · Failed: $liveFailed")
                            Text(liveProgressMessage)
                            Text("Renaming continues in the background if you leave this screen or switch apps. Return here to check progress and the final result.", style = MaterialTheme.typography.bodyMedium)
                            Spacer(Modifier.height(8.dp))
                            Button(onClick = { showProgressPage = false }, modifier = Modifier.fillMaxWidth()) { Text("Back to file selection") }
                        } else {
                            Text("Choose files or a folder. Renaming continues in the background if you leave the app.")
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(onClick = { launchFilePicker() }, modifier = Modifier.weight(1f)) { Text("Pick files") }
                                OutlinedButton(onClick = { pickFolder.launch(null) }, modifier = Modifier.weight(1f)) { Text("Pick folder") }
                            }
                            Text("Selected items: ${selected.size}", style = MaterialTheme.typography.titleMedium)
                            LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                items(selected.toList()) { uri ->
                                    // Do not let an unusual document provider crash Compose while drawing the selection list.
                                    val label = remember(uri) { safeDisplayName(uri) }
                                    Card(Modifier.fillMaxWidth()) { Text(label, Modifier.padding(12.dp), maxLines = 2) }
                                }
                            }
                            Text(status)
                            Button(onClick = { startRenameJob() }, enabled = selected.isNotEmpty(), modifier = Modifier.fillMaxWidth()) { Text("Rename selected items") }
                            OutlinedButton(onClick = { createExport.launch("renamed-files.zip") }, enabled = selected.isNotEmpty() && !exporting, modifier = Modifier.fillMaxWidth()) { Text(if (exporting) "Exporting files…" else "Save / Export selected files as ZIP") }
                            OutlinedButton(onClick = { shareSelectedFiles() }, enabled = selected.isNotEmpty() && !exporting, modifier = Modifier.fillMaxWidth()) { Text(if (exporting) "Preparing files…" else "Share renamed files / Email") }
                            OutlinedButton(onClick = { selected.clear(); persistSelection(); status = "Selection cleared." }, modifier = Modifier.fillMaxWidth()) { Text("Clear selection") }
                            Text("Save a ZIP to your device, or share a ZIP through Gmail or another compatible app.", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
        }
    }


    private fun safeDisplayName(uri: Uri): String {
        return try {
            val treeName = runCatching {
                if (android.provider.DocumentsContract.isTreeUri(uri)) DocumentFile.fromTreeUri(this, uri)?.name else null
            }.getOrNull()
            val singleName = runCatching { DocumentFile.fromSingleUri(this, uri)?.name }.getOrNull()
            treeName ?: singleName ?: uri.lastPathSegment ?: "Selected file"
        } catch (_: Throwable) {
            "Selected file (${uri.lastPathSegment ?: "name unavailable"})"
        }
    }

    private fun launchFilePicker() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        pickFiles.launch(intent)
    }

    private data class ExportItem(val file: DocumentFile, val path: String)

    private fun exportSelected(destination: Uri) {
        if (exporting) return
        exporting = true
        status = "Preparing ZIP export…"
        val selectedSnapshot = selected.toList()
        lifecycleScope.launch {
            val result = withContext(Dispatchers.IO) {
                try {
                    val items = mutableListOf<ExportItem>()
                    val visited = mutableSetOf<String>()
                    selectedSnapshot.forEach { uri ->
                        val item = if (android.provider.DocumentsContract.isTreeUri(uri)) DocumentFile.fromTreeUri(this@MainActivity, uri)
                                   else DocumentFile.fromSingleUri(this@MainActivity, uri)
                        if (item != null) collectForExport(item, item.name?.takeIf { item.isDirectory }.orEmpty(), items, visited)
                    }
                    if (items.isEmpty()) throw IllegalStateException("No accessible files found to export.")
                    val output = contentResolver.openOutputStream(destination) ?: throw IllegalStateException("Could not open the ZIP destination for writing.")
                    var exported = 0
                    var skipped = 0
                    val examples = mutableListOf<String>()
                    val usedPaths = mutableSetOf<String>()
                    output.use { raw ->
                        ZipOutputStream(raw).use { zip ->
                            items.forEach { entry ->
                                val safePath = entry.path.replace('\\', '/').trimStart('/')
                                if (safePath.isNotBlank()) {
                                    try {
                                        val input = contentResolver.openInputStream(entry.file.uri)
                                            ?: throw IllegalStateException("file could not be opened")
                                        input.use { source ->
                                            var entryPath = safePath
                                            var suffix = 2
                                            while (!usedPaths.add(entryPath)) {
                                                val slash = safePath.lastIndexOf('/')
                                                val dot = safePath.lastIndexOf('.').takeIf { it > slash } ?: safePath.length
                                                entryPath = safePath.substring(0, dot) + " ($suffix)" + safePath.substring(dot)
                                                suffix++
                                            }
                                            zip.putNextEntry(ZipEntry(entryPath))
                                            source.copyTo(zip)
                                            zip.closeEntry()
                                        }
                                        exported++
                                    } catch (e: Exception) {
                                        skipped++
                                        if (examples.size < 4) examples.add("${entry.file.name ?: safePath}: ${e.message ?: e.javaClass.simpleName}")
                                        runCatching { zip.closeEntry() }
                                    }
                                }
                            }
                        }
                    }
                    "Export finished: $exported files saved to ZIP; $skipped skipped." +
                        if (examples.isEmpty()) "" else " Examples: ${examples.joinToString(" | ")}"
                } catch (e: Exception) {
                    "Export failed: ${e.message ?: e.javaClass.simpleName}"
                }
            }
            exporting = false
            if (result.startsWith("Export finished:")) lastExportUri = destination
            status = result
        }
    }

    private fun shareSelectedFiles() {
        if (exporting || selected.isEmpty()) return
        exporting = true
        status = "Preparing renamed files to share…"
        val selectedSnapshot = selected.toList()
        lifecycleScope.launch {
            val sharedFile = withContext(Dispatchers.IO) {
                runCatching {
                    val items = mutableListOf<ExportItem>()
                    val visited = mutableSetOf<String>()
                    selectedSnapshot.forEach { uri ->
                        val item = if (android.provider.DocumentsContract.isTreeUri(uri)) DocumentFile.fromTreeUri(this@MainActivity, uri)
                                   else DocumentFile.fromSingleUri(this@MainActivity, uri)
                        if (item != null) collectForExport(item, item.name?.takeIf { item.isDirectory }.orEmpty(), items, visited)
                    }
                    check(items.isNotEmpty()) { "No accessible files found to share." }
                    val shareDir = java.io.File(cacheDir, "shared_exports")
                    if (!shareDir.exists()) check(shareDir.mkdirs()) { "Could not prepare temporary export folder." }
                    val zipFile = java.io.File(shareDir, "renamed-files.zip")
                    var exported = 0
                    val usedPaths = mutableSetOf<String>()
                    java.io.FileOutputStream(zipFile).use { raw ->
                        ZipOutputStream(raw).use { zip ->
                            items.forEach { entry ->
                                val safePath = entry.path.replace('\\', '/').trimStart('/')
                                if (safePath.isNotBlank()) {
                                    val input = contentResolver.openInputStream(entry.file.uri)
                                        ?: throw IllegalStateException("Could not open ${entry.file.name ?: safePath}.")
                                    input.use { source ->
                                        var entryPath = safePath
                                        var suffix = 2
                                        while (!usedPaths.add(entryPath)) {
                                            val slash = safePath.lastIndexOf('/')
                                            val dot = safePath.lastIndexOf('.').takeIf { it > slash } ?: safePath.length
                                            entryPath = safePath.substring(0, dot) + " ($suffix)" + safePath.substring(dot)
                                            suffix++
                                        }
                                        zip.putNextEntry(ZipEntry(entryPath))
                                        source.copyTo(zip)
                                        zip.closeEntry()
                                    }
                                    exported++
                                }
                            }
                        }
                    }
                    check(exported > 0) { "No files could be added to the share ZIP." }
                    zipFile
                }.getOrNull()
            }
            exporting = false
            if (sharedFile == null) {
                status = "Could not prepare files to share. Check that the selected files are still accessible."
                return@launch
            }
            try {
                val shareUri = FileProvider.getUriForFile(this@MainActivity, "$packageName.fileprovider", sharedFile)
                val sendIntent = Intent(Intent.ACTION_SEND).apply {
                    type = "application/zip"
                    putExtra(Intent.EXTRA_STREAM, shareUri)
                    putExtra(Intent.EXTRA_SUBJECT, "Renamed files")
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    clipData = android.content.ClipData.newUri(contentResolver, "Renamed files ZIP", shareUri)
                }
                startActivity(Intent.createChooser(sendIntent, "Share renamed files"))
                status = "Share menu opened. Choose Gmail, another email app, or another sharing app."
            } catch (e: Exception) {
                status = "Could not open sharing apps: ${e.message ?: e.javaClass.simpleName}"
            }
        }
    }

    private fun collectForExport(item: DocumentFile, prefix: String, output: MutableList<ExportItem>, visited: MutableSet<String>) {
        val key = item.uri.toString()
        if (!visited.add(key)) return
        if (item.isDirectory) {
            val children = try { item.listFiles() } catch (_: Exception) { emptyArray() }
            children.forEach { child ->
                val childName = child.name ?: "unnamed-file"
                val path = if (prefix.isBlank()) childName else "$prefix/$childName"
                try { collectForExport(child, path, output, visited) } catch (_: Exception) { }
            }
        } else {
            val path = prefix.ifBlank { item.name ?: "unnamed-file" }
            output.add(ExportItem(item, path))
        }
    }

    private fun persistSelection() {
        getSharedPreferences("smart_renamer", MODE_PRIVATE).edit()
            .putString("selected_uris", selected.joinToString("\n") { it.toString() })
            .apply()
    }

    private fun startRenameJob() {
        if (selected.isEmpty()) {
            status = "Choose files or a folder first."
            return
        }
        try {
            val jobKey = "job_" + java.util.UUID.randomUUID().toString()
            // Keep potentially many URIs out of WorkManager's 10 KB Data payload limit.
            getSharedPreferences("smart_renamer", MODE_PRIVATE).edit()
                .putString(jobKey, selected.joinToString("\n") { it.toString() })
                .apply()
            val request = OneTimeWorkRequestBuilder<RenameWorker>()
                .setInputData(workDataOf("jobKey" to jobKey))
                .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 10, TimeUnit.SECONDS)
                .addTag("smart-renamer")
                .build()
            WorkManager.getInstance(this).enqueueUniqueWork("smart-renamer-${System.currentTimeMillis()}", ExistingWorkPolicy.KEEP, request)
            showProgressPage = true
            liveJobState = "Enqueued"
            liveProgress = 0
            liveProgressMessage = "Job queued. Scanning selected files…"
            status = "Job started. You can leave the app; the rename job continues in the background."
        } catch (e: Exception) {
            status = "Could not start rename job: ${e.message ?: e.javaClass.simpleName}"
        }
    }
}
