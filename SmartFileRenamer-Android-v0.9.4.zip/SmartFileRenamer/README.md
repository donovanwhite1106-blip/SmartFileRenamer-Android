# Smart File Renamer Android — v0.9.0 YGOPRODeck card matching + operation controls

This version is designed for Yu-Gi-Oh! card-image folders such as `Folder 1.zip` (4,468 JPG files, most named with numeric image IDs).

## What changed

- Uses the free YGOPRODeck v7 card catalog: `https://db.ygoprodeck.com/api/v7/cardinfo.php`.
- Maps numeric filenames to `card_images[].id`, which covers alternate artwork image IDs as well as standard artwork.
- For non-numeric filenames, only normalizes names that exactly match a catalog card name after punctuation/case normalization.
- Does **not** use ML Kit's generic image labels or Google Cloud Vision. No paid image API, API key, or per-image charge is required.
- Downloads the catalog once and caches it locally for up to seven days. A saved stale catalog can be used offline if refreshing fails.
- Unknown IDs and unmatched names are left unchanged. There is no fallback to guessed labels such as “poster”.
- Defaults to **Preview only — do not change files**. Preview runs show how many files would be renamed without modifying the selected folder. Turn preview off only after reviewing results and testing a small batch.
- Alternate artworks resolving to the same card name receive a numbered suffix to avoid generating identical target names within the batch.
- Adds a permanent **Cancel Operation** action. Cancelling stops the current unique WorkManager operation and clears any tagged queued work.
- Only one operation can run at a time. A second operation is rejected until the first is finished or cancellation is confirmed; scans are never queued behind one another.
- Every run receives a fresh operation ID and temporary URI list. That list is deleted when the worker ends. There are no checkpoints, pause/resume records, or automatic restart points.
- Selecting the same folder in a later operation starts scanning from the beginning. Files already renamed before cancellation remain renamed; cancellation does not roll back completed file changes.
- WorkManager progress updates are batched (at most every 25 files or 1.5 seconds), and foreground notification refreshes are limited to about every 10 seconds to reduce battery overhead.
- Cancelling also cancels the active YGOPRODeck catalog HTTP request. Existing verified rename reporting remains in place.

## First test on a phone

1. Install the APK produced by the repository's GitHub Actions build.
2. Open Smart File Renamer and keep **Preview only — do not change files** checked.
3. Choose **Pick files** and select only 5 numeric JPG images from the extracted card folder. You can also pick a folder, but a five-file test is recommended first.
4. Start the run and wait for the completion notification. The first run needs internet access to download the catalog; later runs use the cached catalog.
5. Review the preview's proposed names. If the catalog cannot be downloaded, the app should leave images unchanged and report that reason.
6. Only after the preview names are correct, select a small backed-up test batch and turn preview off. Do not start with all 4,468 files until the small test is satisfactory.

## Build

The project is nested under `SmartFileRenamer/` for the repository's existing workflow, which unpacks `SmartFileRenamer-Android-Starter.zip`, then runs `gradle assembleDebug` on Java 17. The debug APK is uploaded as the `SmartFileRenamer-APK` workflow artifact.

## Important limitations

- The app currently identifies images by the filename's numeric YGOPRODeck image ID or an exact card-name match. It does **not** yet perform visual similarity matching on arbitrary images with unrelated filenames.
- The supplied archive has 4,468 JPG files, 4,429 with numeric basenames and 39 with non-numeric names. The catalog mapping should cover the numeric ones only when their basename matches a YGOPRODeck `card_images[].id` value. Non-matches are deliberately not guessed.
- This source package has been statically inspected and ZIP integrity can be checked locally, but it has **not** been compiled with Gradle or tested on a physical Android device in this environment. The GitHub Actions build and the first on-device preview are still required before a real rename run. Cancellation, queue exclusivity, battery-update throttling, and restart-from-zero behavior still need on-device verification.

## Reference

YGOPRODeck API Guide: https://ygoprodeck.com/api-guide/
The API guide recommends caching the catalog and image data locally, and warns against repeatedly hotlinking image files. This implementation requests the catalog only and caches its response; it does not download every card image.


## v0.9.2 image recognition restoration

Image files are identified from their actual image content again, restoring the earlier Google Lens upload flow with free on-device ML Kit image labeling as a fallback. Numeric filenames are no longer treated as proof of card identity. If neither recognizer produces a usable result, the original filename is kept. Lens uses an undocumented web endpoint and may change or be rate-limited; images sent to Lens are uploaded to Google. ML Kit fallback processing stays on-device and produces general labels, which are less reliable for exact Yu-Gi-Oh! card names. Cancellation attempts to cancel the active Lens network request.


## v0.9.4 recognition accuracy
- Google Lens result titles are no longer accepted as filenames just because they look descriptive.
- A Lens candidate must exactly match a normalized official Yu-Gi-Oh! card name in the YGOPRODeck catalog.
- Generic on-device image labels are no longer used as card names, preventing labels such as “poster”, “dragon”, or “artwork” from becoming filenames.
- If there is no exact verified card-name match, the original filename is preserved.
- This conservative mode can leave some real cards unchanged when Lens returns extra text, but it is designed to avoid incorrect renames.
