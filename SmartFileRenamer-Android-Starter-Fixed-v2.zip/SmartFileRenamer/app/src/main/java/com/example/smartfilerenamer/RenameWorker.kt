package com.example.smartfilerenamer

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.net.Uri
import android.os.Build
import android.provider.DocumentsContract
import androidx.core.app.NotificationCompat
import androidx.documentfile.provider.DocumentFile
import androidx.work.CoroutineWorker
import androidx.work.ForegroundInfo
import androidx.work.WorkerParameters
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class RenameWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    private val channelId = "renamer_jobs"
    private val progressId = 4102
    private val resultId = 4103

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        createChannel()
        val rawUris = inputData.getStringArray("uris") ?: emptyArray()
        if (rawUris.isEmpty()) {
            notifyResult("Nothing selected", "Return to the app and select files.")
            return@withContext Result.failure(workDataOf("error" to "Nothing selected"))
        }
        var renamed = 0
        var unchanged = 0
        var failed = 0
        var scanned = 0
        val files = mutableListOf<DocumentFile>()
        val seen = mutableSetOf<String>()
        val scanErrors = mutableListOf<String>()
        try {
            rawUris.forEach { raw ->
                if (isStopped) return@withContext Result.failure()
                val uri = Uri.parse(raw)
                try {
                    if (DocumentsContract.isTreeUri(uri)) {
                        val root = DocumentFile.fromTreeUri(applicationContext, uri)
                        if (root != null) collect(root, files, seen, scanErrors) else scanErrors.add("Could not open selected folder")
                    } else {
                        val file = DocumentFile.fromSingleUri(applicationContext, uri)
                        if (file != null && seen.add(file.uri.toString())) files.add(file)
                        else scanErrors.add("Could not open one selected item")
                    }
                } catch (e: Exception) { scanErrors.add("Folder scan issue: ${e.message ?: e.javaClass.simpleName}") }
            }
            if (files.isEmpty()) {
                val details = scanErrors.take(3).joinToString("; ").ifBlank { "No accessible files were found. Check folder permissions." }
                notifyResult("No files found", details)
                return@withContext Result.failure(workDataOf("error" to details))
            }
            val total = files.size
            files.forEachIndexed { index, file ->
                if (isStopped) return@withContext Result.failure(workDataOf("message" to "Stopped after $scanned of $total files"))
                try {
                    val oldName = file.name
                    if (oldName.isNullOrBlank() || !file.isFile) {
                        unchanged++
                    } else {
                        val newName = FileNameHeuristics.suggest(oldName)
                        if (newName == oldName) {
                            unchanged++
                        } else {
                            val renamedUri = runCatching {
                                DocumentsContract.renameDocument(applicationContext.contentResolver, file.uri, newName)
                            }.getOrNull()
                            val verifiedUri = renamedUri ?: run {
                                val fallbackSucceeded = runCatching { file.renameTo(newName) }.getOrDefault(false)
                                if (fallbackSucceeded) file.uri else null
                            }
                            val refreshedName = verifiedUri?.let { queryDisplayName(it) }
                            // Never report success just because a provider returned true: verify the name.
                            if (refreshedName == newName) renamed++ else failed++
                        }
                    }
                } catch (_: SecurityException) { failed++ }
                catch (_: Exception) { failed++ }
                scanned = index + 1
                val percent = scanned * 100 / total
                val message = "Processed $scanned of $total files · renamed $renamed · failed $failed"
                setProgress(workDataOf("progress" to percent, "message" to message, "total" to total, "processed" to scanned))
                // Progress remains recorded in WorkManager even if the system notification cannot update.
                runCatching { setForeground(buildForegroundInfo(message, percent, false)) }
            }
            val scanNote = if (scanErrors.isNotEmpty()) " · scan warnings ${scanErrors.size}" else ""
            val summary = "Finished $scanned of $total files · renamed $renamed · unchanged $unchanged · failed $failed$scanNote"
            notifyResult("Smart File Renamer finished", summary)
            val output = workDataOf("message" to summary, "renamed" to renamed, "unchanged" to unchanged, "failed" to failed, "processed" to scanned, "total" to total, "scanWarnings" to scanErrors.size)
            if (renamed == 0 && failed > 0) Result.failure(output) else Result.success(output)
        } catch (e: Exception) {
            val message = "Stopped after $scanned files: ${e.message ?: e.javaClass.simpleName}"
            notifyResult("Rename job stopped", message)
            Result.failure(workDataOf("error" to message, "processed" to scanned))
        }
    }

    private fun queryDisplayName(uri: Uri): String? = try {
        applicationContext.contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) cursor.getString(0) else null
        }
    } catch (_: Exception) { null }

    private fun collect(item: DocumentFile, output: MutableList<DocumentFile>, seen: MutableSet<String>, warnings: MutableList<String>) {
        val key = item.uri.toString()
        if (!seen.add("visited:$key")) return // Avoid cycles from unusual document providers.
        try {
            if (item.isDirectory) {
                val children = item.listFiles()
                children.forEach { child ->
                    try { collect(child, output, seen, warnings) }
                    catch (e: Exception) { warnings.add("Skipped inaccessible item: ${e.message ?: e.javaClass.simpleName}") }
                }
            } else if (item.isFile) {
                // The visited marker is separate from the file de-duplication key.
                if (seen.add("file:$key")) output.add(item)
            }
        } catch (e: Exception) { warnings.add("Could not read ${item.name ?: "folder"}: ${e.message ?: e.javaClass.simpleName}") }
    }

    private fun createChannel() {
        val manager = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            manager.createNotificationChannel(NotificationChannel(channelId, "File renaming progress", NotificationManager.IMPORTANCE_LOW))
        }
    }

    private fun buildForegroundInfo(message: String, progress: Int, indeterminate: Boolean): ForegroundInfo {
        val notification = NotificationCompat.Builder(applicationContext, channelId)
            .setContentTitle("Smart File Renamer")
            .setContentText(message)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setOnlyAlertOnce(true)
            .setOngoing(true)
            .setProgress(100, progress.coerceIn(0, 100), indeterminate)
            .build()
        return ForegroundInfo(progressId, notification)
    }

    private fun notifyResult(title: String, message: String) {
        val manager = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(resultId, NotificationCompat.Builder(applicationContext, channelId)
            .setContentTitle(title).setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setSmallIcon(android.R.drawable.stat_sys_download_done).setAutoCancel(true).build())
    }
}

object FileNameHeuristics {
    private val badChars = Regex("""[\\/:*?"<>|\p{Cntrl}]""")
    fun suggest(original: String): String {
        val ext = original.substringAfterLast('.', "").takeIf { it.isNotBlank() && !original.endsWith('.') }
        val base = if (ext == null) original else original.dropLast(ext.length + 1)
        val cleaned = base.replace('_', ' ').replace('-', ' ')
            .replace(Regex("""\s+"""), " ").trim().replace(badChars, "")
        var safe = cleaned.ifBlank { "renamed file" }.take(120).trim()
        if (safe.equals(base, ignoreCase = false)) {
            val prefix = when ((ext ?: "").lowercase()) {
                "jpg", "jpeg", "png", "gif", "webp", "heic", "bmp" -> "Image"
                "pdf", "doc", "docx", "txt", "rtf", "odt" -> "Document"
                "mp4", "mov", "mkv", "avi", "webm" -> "Video"
                "mp3", "wav", "m4a", "flac", "ogg" -> "Audio"
                "zip", "7z", "rar", "tar", "gz" -> "Archive"
                else -> "File"
            }
            if (!safe.startsWith("$prefix ")) safe = "$prefix $safe"
        }
        return safe + if (ext != null) ".$ext" else ""
    }
}
