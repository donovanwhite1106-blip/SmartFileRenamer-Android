package com.example.smartfilerenamer

import android.content.Context
import android.net.Uri
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.IOException
import java.util.Base64
import java.util.Locale
import java.util.concurrent.TimeUnit

/** Uses Google Cloud Vision Web Detection to find web matches and descriptive labels for a local image. */
object GoogleImageNameResolver {
    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(40, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .callTimeout(50, TimeUnit.SECONDS)
        .build()

    private val imageExtensions = setOf("jpg", "jpeg", "png", "gif", "webp", "bmp", "heic", "heif", "tif", "tiff")
    private val genericLabels = setOf(
        "image", "photo", "photograph", "picture", "screenshot", "clip art", "graphic",
        "jpeg", "jpg", "png", "webp", "bitmap", "file", "unknown", "visual content"
    )
    private val invalidFilenameChars = Regex("""[\\/:*?\"<>|\p{Cntrl}]""")
    private val whitespace = Regex("\\s+")

    fun isImage(name: String): Boolean = name.substringAfterLast('.', "").lowercase(Locale.ROOT) in imageExtensions

    /** Returns a descriptive base name (without extension), or null if Google has no useful result. */
    fun suggestBaseName(context: Context, uri: Uri, apiKey: String): String? {
        if (apiKey.isBlank()) throw IOException("Google Cloud Vision API key is not set. Add it in Google Image Search settings.")
        val bytes = context.contentResolver.openInputStream(uri)?.use { input ->
            val out = java.io.ByteArrayOutputStream()
            val buffer = ByteArray(16 * 1024)
            var total = 0
            while (true) {
                val count = input.read(buffer)
                if (count < 0) break
                total += count
                // Inline Vision requests grow by about one third when Base64-encoded. Keep a margin under the request limit.
                if (total > 12 * 1024 * 1024) throw IOException("Image is larger than 12 MB. Resize it before online identification.")
                out.write(buffer, 0, count)
            }
            out.toByteArray()
        } ?: throw IOException("Android could not read this image.")
        if (bytes.isEmpty()) throw IOException("This image file is empty.")

        val encoded = Base64.getEncoder().encodeToString(bytes)
        val requestJson = JSONObject().apply {
            put("requests", org.json.JSONArray().put(JSONObject().apply {
                put("image", JSONObject().put("content", encoded))
                put("features", org.json.JSONArray().put(JSONObject().apply {
                    put("type", "WEB_DETECTION")
                    put("maxResults", 10)
                }))
            }))
        }
        val url = "https://vision.googleapis.com/v1/images:annotate".toHttpUrl().newBuilder()
            .addQueryParameter("key", apiKey)
            .build()
        val request = Request.Builder()
            .url(url)
            .post(requestJson.toString().toRequestBody("application/json; charset=utf-8".toMediaType()))
            .build()

        val responseText = client.newCall(request).execute().use { response ->
            val bodyText = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                val detail = runCatching { JSONObject(bodyText).optJSONObject("error")?.optString("message") }.getOrNull()
                throw IOException("Google Vision request failed (${response.code})${detail?.takeIf { it.isNotBlank() }?.let { ": $it" } ?: ". Check API key, billing, and internet access."}")
            }
            bodyText
        }

        val root = JSONObject(responseText)
        val first = root.optJSONArray("responses")?.optJSONObject(0)
            ?: throw IOException("Google returned an empty image-identification response.")
        first.optJSONObject("error")?.optString("message")?.takeIf { it.isNotBlank() }?.let {
            throw IOException("Google Vision: $it")
        }
        val web = first.optJSONObject("webDetection") ?: return null

        // Prefer specific web entities, but reject generic words that would recreate the old prefix-only behavior.
        val entities = web.optJSONArray("webEntities")
        val candidates = mutableListOf<Pair<Double, String>>()
        if (entities != null) {
            for (i in 0 until entities.length()) {
                val entity = entities.optJSONObject(i) ?: continue
                val label = entity.optString("description").trim()
                val score = entity.optDouble("score", 0.0)
                if (isUseful(label)) candidates.add(score to label)
            }
        }
        val bestEntity = candidates.sortedByDescending { it.first }.firstOrNull()
        if (bestEntity != null && bestEntity.first >= 0.35) return cleanLabel(bestEntity.second)

        val guesses = web.optJSONArray("bestGuessLabels")
        if (guesses != null) {
            for (i in 0 until guesses.length()) {
                val label = guesses.optJSONObject(i)?.optString("label")?.trim().orEmpty()
                if (isUseful(label)) return cleanLabel(label)
            }
        }
        return bestEntity?.second?.let(::cleanLabel)
    }

    private fun isUseful(value: String): Boolean {
        val normalized = value.trim().lowercase(Locale.ROOT)
        return normalized.isNotBlank() && normalized !in genericLabels && normalized.length >= 3 &&
            normalized.any { it.isLetterOrDigit() }
    }

    fun cleanLabel(value: String): String? {
        val cleaned = whitespace.replace(value.replace(invalidFilenameChars, " ").replace('_', ' ').trim(), " ")
            .trim(' ', '.', '-', '_')
            .take(100)
            .trim()
        if (cleaned.isBlank() || !isUseful(cleaned)) return null
        return cleaned.replace(Regex("[. ]+$"), "")
            .replaceFirstChar { if (it.isLowerCase()) it.titlecase(Locale.ROOT) else it.toString() }
            .takeIf { it.isNotBlank() }
    }
}
